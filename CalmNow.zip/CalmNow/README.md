# Calm Now

A single-screen Android app for riding out a panic attack. It opens straight to a guided breathing circle (4s in, 4s hold, 6s out), followed by the 5-4-3-2-1 grounding exercise and a few gentle reminders. No buttons to hunt for, no setup — just open it and breathe.

Built with Kotlin and Jetpack Compose. The app follows the phone's system theme: airy sky blue and sage by day, soft navy after dark.

## Run it

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Open Android Studio → **File → Open** → select this `CalmNow` folder.
3. Let Gradle sync (first sync downloads dependencies, so you'll need internet). If Android Studio mentions a missing Gradle wrapper, accept its offer to fix it — this project ships without the wrapper binary.
4. Connect an Android phone with USB debugging enabled (or start an emulator) and press **Run ▶**.

To put it on a phone permanently without a cable each time: **Build → Generate Signed App Bundle / APK → APK**, then copy the APK to the phone and install it.

## Or: build it on GitHub (no Android Studio needed)

The project includes a GitHub Actions workflow (`.github/workflows/build.yml`) that compiles the app in the cloud and hands you the APK as a zip download.

1. Create a free GitHub account and a new repository (public or private both work).
2. **Extract this zip first** — GitHub won't build a zip file itself. Then upload everything *inside* the `CalmNow` folder to the repository **root** (so `settings.gradle.kts` sits at the top level, not inside a subfolder).
3. Make sure the hidden `.github` folder gets uploaded too — it holds the build recipe. On a Mac press Cmd+Shift+. in Finder to reveal hidden files; on Windows enable View → Hidden items. Easiest routes: drag all items into GitHub's "Add file → Upload files" page, or use GitHub Desktop.
4. Commit. The **Build APK** workflow starts automatically — watch it under the repo's **Actions** tab (takes about 3–5 minutes).
5. When it's green, open the run and scroll to **Artifacts**: download **CalmNow-debug-apk**. It arrives as a zip; inside is `CalmNow.apk`.
6. Copy the APK to your Android phone and tap it to install (you'll be asked to allow installs from unknown sources — that's normal for apps outside the Play Store).

The workflow installs its own Gradle, so the missing wrapper binary is not a problem. You can also trigger a build manually any time from the Actions tab ("Run workflow").

## Customize

Everything lives in one file: `app/src/main/java/com/example/calmnow/MainActivity.kt`

- **Colors** — the `DayPalette` and `NightPalette` constants at the top of the file.
- **Breathing rhythm** — the `BreathPhase` enum (labels, seconds, circle size). Swap in box breathing by making it 4-4-4 plus a second hold.
- **All text** — the strings inside `CalmScreen()`.
- **App name** — `app/src/main/res/values/strings.xml`.

## A note on the content

The reassurance lines follow standard psychoeducation used in CBT for panic: the attack is time-limited, not dangerous, and fighting it tends to prolong it. The footer deliberately keeps two doors open — professional help for recurring attacks, and medical care for symptoms that are new or different.
