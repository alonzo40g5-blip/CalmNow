package com.example.calmnow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// ---------- Two palettes: dawn by day, dusk by night ----------

@Immutable
data class CalmPalette(
    val bgTop: Color,
    val bgBottom: Color,
    val text: Color,
    val dim: Color,
    val accent: Color,
    val cardBg: Color,
    val cardBorder: Color,
    val chipBg: Color,
    val chipText: Color,
    val orb: Color,
    val ring: Color,
    val footer: Color
)

private val DayPalette = CalmPalette(
    bgTop = Color(0xFFE9F2FA),     // pale sky
    bgBottom = Color(0xFFF4F7F0),  // soft cream-sage
    text = Color(0xFF2E4257),      // soft navy, not harsh black
    dim = Color(0xFF74879D),
    accent = Color(0xFF4E79B0),    // trust blue
    cardBg = Color.White.copy(alpha = 0.78f),
    cardBorder = Color(0xFF4E79B0).copy(alpha = 0.10f),
    chipBg = Color(0xFF7BA483).copy(alpha = 0.20f),  // sage
    chipText = Color(0xFF55795F),
    orb = Color(0xFF76A0D4),       // sky blue
    ring = Color(0xFF4E79B0).copy(alpha = 0.28f),
    footer = Color(0xFF74879D).copy(alpha = 0.95f)
)

private val NightPalette = CalmPalette(
    bgTop = Color(0xFF0D1726),
    bgBottom = Color(0xFF13233C),
    text = Color(0xFFE8EEF9),
    dim = Color(0xFF9FAFC8),
    accent = Color(0xFFAFC4F5),    // periwinkle
    cardBg = Color(0xFF182A45).copy(alpha = 0.75f),
    cardBorder = Color.Transparent,
    chipBg = Color(0xFFAFC4F5).copy(alpha = 0.16f),
    chipText = Color(0xFFAFC4F5),
    orb = Color(0xFFAFC4F5),
    ring = Color(0xFFAFC4F5).copy(alpha = 0.25f),
    footer = Color(0xFF9FAFC8).copy(alpha = 0.8f)
)

private val LocalPalette = staticCompositionLocalOf { NightPalette }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val palette = if (dark) NightPalette else DayPalette
            val scheme = if (dark) {
                darkColorScheme(
                    primary = palette.accent,
                    background = palette.bgTop,
                    onBackground = palette.text
                )
            } else {
                lightColorScheme(
                    primary = palette.accent,
                    background = palette.bgTop,
                    onBackground = palette.text
                )
            }
            CompositionLocalProvider(LocalPalette provides palette) {
                MaterialTheme(colorScheme = scheme) {
                    CalmScreen()
                }
            }
        }
    }
}

// ---------- Screen ----------

@Composable
fun CalmScreen() {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            Text(
                text = "You're okay.",
                fontSize = 32.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "What you're feeling is intense, but it is not dangerous — and it will pass. Breathe with the circle.",
                fontSize = 16.sp,
                lineHeight = 24.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(28.dp))
            BreathingCircle()
            Spacer(Modifier.height(10.dp))
            Text(
                text = "A longer breath out tells your body the danger has passed.",
                fontSize = 14.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(32.dp))
            SectionCard(title = "Ground yourself · 5-4-3-2-1") {
                GroundingRow("5", "things you can see around you")
                GroundingRow("4", "things you can touch or feel")
                GroundingRow("3", "sounds you can hear")
                GroundingRow("2", "things you can smell")
                GroundingRow("1", "thing you can taste")
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Go slowly. Name them out loud if you can.",
                    fontSize = 14.sp,
                    color = c.dim
                )
            }

            Spacer(Modifier.height(16.dp))
            SectionCard(title = "Remember") {
                ReassuranceLine("Panic usually peaks within a few minutes, then fades. It always passes.")
                ReassuranceLine("This is your body's alarm going off by mistake. It feels awful, but it isn't harming you.")
                ReassuranceLine("Don't fight the wave. Let it rise, crest, and fall on its own.")
                ReassuranceLine("Cool water on your face or hands can help settle your body.")
            }

            Spacer(Modifier.height(28.dp))
            Text(
                text = "Panic attacks are common and very treatable. If they keep happening, a doctor or therapist can genuinely help.\n\nChest pain that is new or different for you? It's always okay to seek medical care — dial 112 anywhere in the EU. For free emotional support, call or text 988 in the US, or call 116 123 in many EU countries.",
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = c.footer,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ---------- Breathing guide (4 in · 4 hold · 6 out) ----------

private enum class BreathPhase(val label: String, val seconds: Int, val targetScale: Float) {
    Inhale("Breathe in", 4, 1f),
    Hold("Hold", 4, 1f),
    Exhale("Breathe out", 6, 0.55f)
}

@Composable
private fun BreathingCircle(modifier: Modifier = Modifier) {
    val c = LocalPalette.current
    var phase by remember { mutableStateOf(BreathPhase.Inhale) }
    var count by remember { mutableIntStateOf(BreathPhase.Inhale.seconds) }
    val scale = remember { Animatable(BreathPhase.Exhale.targetScale) }

    LaunchedEffect(Unit) {
        while (isActive) {
            for (p in BreathPhase.entries) {
                phase = p
                count = p.seconds
                coroutineScope {
                    launch {
                        scale.animateTo(
                            targetValue = p.targetScale,
                            animationSpec = tween(
                                durationMillis = p.seconds * 1000,
                                easing = FastOutSlowInEasing
                            )
                        )
                    }
                    launch {
                        repeat(p.seconds) { i ->
                            count = p.seconds - i
                            delay(1000L)
                        }
                    }
                }
            }
        }
    }

    Box(modifier = modifier.size(280.dp), contentAlignment = Alignment.Center) {
        // Outer guide ring: the size the breath grows toward
        Box(
            Modifier
                .matchParentSize()
                .border(1.5.dp, c.ring, CircleShape)
        )
        // The breathing circle itself
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .background(
                    Brush.radialGradient(
                        listOf(
                            c.orb.copy(alpha = 0.48f),
                            c.orb.copy(alpha = 0.08f)
                        )
                    ),
                    CircleShape
                )
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = phase.label,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
                color = c.text
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = count.toString(),
                fontSize = 44.sp,
                fontWeight = FontWeight.Light,
                color = c.text.copy(alpha = 0.9f)
            )
        }
    }
}

// ---------- Small building blocks ----------

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(c.cardBg, RoundedCornerShape(20.dp))
            .border(1.dp, c.cardBorder, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.accent
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun GroundingRow(number: String, text: String) {
    val c = LocalPalette.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(c.chipBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = c.chipText,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 16.sp,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun ReassuranceLine(text: String) {
    val c = LocalPalette.current
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Text(text = "·", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 15.sp,
            lineHeight = 22.sp
        )
    }
}
