# RULES — Calm Now

## The agreement
This is the owner's project. I build what the owner asks, the way the owner says.
- The owner decides. I do not make design or content choices for him. When something is ambiguous I ask or I show an option first — I do not just pick.
- When the owner says exactly what he wants (a hex, a layout, a behaviour), I do that thing — not my interpretation of it, not a partial version I then call finished.
- I read the request literally. "In the centre" means centre. "Flip like a book" means the page is draggable by finger, not a tapped animation. If I only did half, it is not done.
- I verify before I hand anything over, and I say plainly what still is not done. I never claim something works when I have not confirmed it.
- I own my mistakes without excuses, fix them fully, and don't repeat them.

## Locked facts — do not change without being asked
### The twelve palettes (background · cards · accent)
Days:
- Day 1 Sky — bg E9F2FA · cards E2EDF8 · accent 4E79B0
- Day 3 Warm Cream — bg F7F2E8 · cards F4EEE1 · accent 7C8F6A
- Day 4 Off-White — bg FBFAF7 · cards EFEBDF · accent 7E7A6C
- Day 5 Mist — bg EDF1F4 · cards DBE2E8 · accent 5A7186
- Day 6 Soft Sage — bg EDF2E9 · cards DBE5D2 · accent 6B8261
- Day 7 Blush — bg F6EFEC · cards EAE0DB · accent 9C7C72

Nights (Forest/Plum/Ember are locked at the owner's chosen +2 step):
- Night 1 Deep Navy — bg 0D1726 · cards 182A45 · accent AFC4F5
- Night 2 Slate — bg 26364D · cards 3A4E6E · accent BDD0F7
- Night 3 Evening Sage — bg 3B473E · cards 536354 · accent CFDFC4
- Night 4 Deep Forest — bg 1A4028 · cards 285E3A · accent D6EAC3
- Night 5 Midnight Plum — bg 2D1F4D · cards 443376 · accent D9CAF5
- Night 6 Ember — bg 3E231D · cards 5E3C2C · accent F2BC9C

"Day 2" is retired. Do not bring it back.

### Hard design rules
- Backgrounds NEVER get lighter than their chosen colour. In the tuner, "lighter" moves cards/glow only; the background is clamped. This is welded in and must stay.
- No pure white (#FFFFFF) as a day card colour, ever.
- The contrast guard that keeps any custom mix readable must stay.
- Breathing rhythm is 4 in · 4 hold · 6 out. (A ~6-breaths/min "slow the heart" mode may be added as an option if asked.)

### The app
- Four pages: (1) the breathing/panic screen, (2) "Make it yours" colour studio via 🎨, (3) "Understanding the waves" book via 📖, (4) Settings via ⚙️ — language dropdown, Day/Night/Auto appearance, reset colours.
- Language system: six languages (en, el, de, fr, es, it). Every user-facing string, including all nine book chapters, lives in Strings.kt; the pick is saved in prefs key "lang" and switches instantly. Crisis numbers are per-language, verified from live sources 2026-07-13: FR 3114 · ES 024 · DE 0800 111 0 111 (TelefonSeelsorge) · EL 1018 · IT Telefono Amico 02 99 777 · 112 everywhere; EN keeps 988 (US) + 116 123 (EU).
- Mix sections pick swatches by kind index (0 bg, 1 cards, 2 circle, 3 accent), never by label text — labels are translated now, so label-matching would silently break.
- The screen never dims or sleeps while the app is open: FLAG_KEEP_SCREEN_ON is set in MainActivity.onCreate. Added at the owner’s request — do not remove it.
- The three round buttons (book, palette, day/night) live IN the page flow above the headline — never as an overlay that can cover content. 56dp with 18dp gaps on tablets; 46dp with 10dp gaps on screens under 480dp. Overlap with the title must be impossible at any width.
- The book is a real swipeable pager (drag to flip), serif body text, responsive to phone and tablet width. The ‹ › arrows sit vertically centred in their own reserved side gutters (three-lane layout: arrow · page · arrow) so they can never cover the words on any screen.
- Medical content is only positive and points people to real help; crisis numbers 988 (US) and 116 123 (much of EU) stay in.

### Build
- Ships as a zip. GitHub Actions (`.github/workflows/build.yml`) unzips it, compiles with Gradle, and outputs `CalmNow.apk` as an artifact. No Gradle wrapper binary is committed on purpose; the workflow installs its own Gradle.
- Kotlin trap that has bitten before: a public function cannot expose a file-private type (e.g. `Mix`). Any function touching `Mix` must be `private`.
- Patch-script trap that has bitten before: a `replace()` whose anchor is missing fails SILENTLY. Every patch must assert its anchor exists, and imports must be verified by grepping the final file — never by trusting the patch output. The audit checks import lines, not just call sites.

## Current state
Latest build: CalmNow-v18.zip (versionName 2.6). v18: the screen stays awake while the app is open (FLAG_KEEP_SCREEN_ON) so it never dims mid-breathing. The repo workflow lives at .github/workflows/build.yml (JDK 17, Gradle 8.9, unzips newest zip, artifacts CalmNow.apk).
