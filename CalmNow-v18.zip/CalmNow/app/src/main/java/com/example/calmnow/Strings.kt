package com.example.calmnow

import androidx.compose.runtime.staticCompositionLocalOf

// ---------- Language system ----------
// Every word the app shows lives here, in six languages.
// The user's pick is saved in prefs ("lang") and applies instantly, app-wide.

data class BookPage(val title: String, val paragraphs: List<String>)

data class L(
    // main screen
    val hl: String, val sub: String, val hint: String,
    val phases: List<String>, // breathe in, hold, breathe out
    val groundTitle: String, val g5: String, val g4: String, val g3: String, val g2: String, val g1: String,
    val groundHint: String,
    val wavesTitle: String, val waves: List<String>,
    val rememberTitle: String, val rem: List<String>,
    val footer: String,
    // play page
    val playBack: String, val playReset: String, val playTitle: String, val playBlurb: String,
    val chooseTheme: String, val mixOpen: String, val mixClosed: String,
    val labBg: String, val labCards: String, val labCircle: String, val labAccent: String, val labDepth: String,
    val depthL2: String, val depthL1: String, val depthYours: String, val depthD1: String, val depthD2: String,
    val playNote: String, val themeWord: String,
    // book page
    val contents: String, val contentsClose: String, val bookTitle: String, val chapterWord: String,
    val bookPages: List<BookPage>,
    // settings page
    val settingsTitle: String, val settingsBack: String,
    val labLanguage: String, val labAppearance: String,
    val segDay: String, val segNight: String, val segAuto: String, val modeRow: String,
    val labColors: String, val resetColors: String, val resetWord: String,
    val madeBy: String
)

val LangOptions = listOf(
    Triple("en", "\uD83C\uDDEC\uD83C\uDDE7", "English"),
    Triple("el", "\uD83C\uDDEC\uD83C\uDDF7", "Ελληνικά"),
    Triple("de", "\uD83C\uDDE9\uD83C\uDDEA", "Deutsch"),
    Triple("fr", "\uD83C\uDDEB\uD83C\uDDF7", "Français"),
    Triple("es", "\uD83C\uDDEA\uD83C\uDDF8", "Español"),
    Triple("it", "\uD83C\uDDEE\uD83C\uDDF9", "Italiano")
)

private val EN = L(
    hl = "You're okay.",
    sub = "What you're feeling is intense, but it is not dangerous — and it will pass. Breathe with the circle.",
    hint = "A longer breath out tells your body the danger has passed.",
    phases = listOf("Breathe in", "Hold", "Breathe out"),
    groundTitle = "Ground yourself · 5-4-3-2-1",
    g5 = "things you can see around you", g4 = "things you can touch or feel",
    g3 = "sounds you can hear", g2 = "things you can smell", g1 = "thing you can taste",
    groundHint = "Go slowly. Name them out loud if you can.",
    wavesTitle = "When the waves keep coming",
    waves = listOf(
        "Panic can roll in waves — one eases, then another builds. This is common and it is not a sign anything is wrong with you.",
        "Each wave leaves your body primed, so a racing heart or fast breathing can trip the next one. Slowing the breath breaks that loop.",
        "A fast heartbeat during panic is adrenaline doing its job, not your heart failing — especially reassuring if a doctor has checked you and found it sound.",
        "If medication that used to help is starting to slip, that is a signal to see your prescriber — not a failing on your part. There are usually more options.",
        "The exhaustion afterward is an adrenaline hangover. Rest, water, and going easy on yourself are the cure; it passes."
    ),
    rememberTitle = "Remember",
    rem = listOf(
        "Panic usually peaks within a few minutes, then fades. It always passes.",
        "This is your body's alarm going off by mistake. It feels awful, but it isn't harming you.",
        "Don't fight the wave. Let it rise, crest, and fall on its own.",
        "Cold shocks the system and can break the wave: press an iced bottle to the back of your neck, or to your lower spine — many find that hits harder. Splashing cold water on your face works too. Keep it moving so it doesn't hurt the skin."
    ),
    footer = "Panic attacks are common and very treatable. If they keep happening, a doctor or therapist can genuinely help.\n\nChest pain that is new or different for you? It's always okay to seek medical care — dial 112 anywhere in the EU. For free emotional support, call or text 988 in the US, or call 116 123 in many EU countries.",
    playBack = "← Back to breathing", playReset = "↩ Reset", playTitle = "Make it yours",
    playBlurb = "Playing with color genuinely calms the brain: gentle, absorbing choosing creates flow and enjoyment, and making your own choices restores a sense of control that softens stress. Every color here was chosen for calm — pick freely, every combination is a good one. And if anything looks odd, one tap on Reset brings it all back. You cannot break this.",
    chooseTheme = "CHOOSE YOUR THEME", mixOpen = "MIX PIECES · OPTIONAL ▲", mixClosed = "MIX PIECES · OPTIONAL ▼",
    labBg = "BACKGROUND", labCards = "CARDS", labCircle = "BREATHING CIRCLE", labAccent = "ACCENT · TITLES & NUMBERS",
    labDepth = "WHOLE THEME · LIGHTER CARDS ← → DARKER ALL (BG NEVER LIGHTENS)",
    depthL2 = "+2", depthL1 = "+1", depthYours = "yours", depthD1 = "−1", depthD2 = "−2",
    playNote = "Made by you, for you — and that ownership is part of what makes it work.",
    themeWord = "Theme:",
    contents = "☰ Contents", contentsClose = "Close", bookTitle = "Understanding the waves", chapterWord = "Chapter",
    bookPages = listOf(
        BookPage("Rolling panic attacks", listOf(
            "What you may be feeling is often called a rolling panic attack — multiple attacks stacking over hours, the boundaries blurring so it feels like one relentless wave instead of a single event that ends.",
            "It's a recognized experience, and the reason it keeps returning is mechanical — not a sign that something is medically wrong.",
            "Knowing it has a name, and a cause, is the first step to taking some of its power away."
        )),
        BookPage("The feedback loop", listOf(
            "The engine behind it is a feedback loop. An attack floods your body with adrenaline and cortisol. As those drop, symptoms ease briefly — but they leave you in a heightened state of arousal, still primed.",
            "In that primed state, a slightly fast heartbeat, mild dizziness, or shallow breathing gets read by the brain as danger again — and that reading re-fires the whole fight-or-flight response, launching the next wave.",
            "So the very sensations left behind by one wave become the trigger for the next."
        )),
        BookPage("Why watching yourself feeds it", listOf(
            "After an attack it's common to start monitoring your own body — watching your breath and heartbeat, braced for the next one.",
            "That hypervigilance is what keeps the nervous system on high alert, which is precisely what feeds the cycle.",
            "It isn't a flaw in you. It's the loop doing what loops do — and it can be interrupted."
        )),
        BookPage("The adrenaline hangover", listOf(
            "What you feel after the waves finally stop — the exhaustion, brain fog, aches, being on edge for hours or days — is a separate thing sometimes called an adrenaline hangover.",
            "It's the natural cost of running at full emergency power, repeatedly. It does not mean you're still in danger.",
            "Rest, water, and going easy on yourself are the cure. It passes."
        )),
        BookPage("It isn't your fault", listOf(
            "Why some people get rolling waves and others get a single attack isn't fully understood.",
            "It's linked to a more sensitized nervous system, from a mix of genetic, biological, and environmental factors.",
            "None of it comes from anything you did wrong."
        )),
        BookPage("Breaking the loop", listOf(
            "The loop can be interrupted, and this app is aimed right at the mechanism.",
            "The breathing lengthens your exhale to pull down the arousal that primes the next wave. For a racing heart, a longer exhale still — around six slow breaths a minute — works best.",
            "The 5-4-3-2-1 forces attention outward, breaking the inward body-scanning that re-triggers you. Mental math helps too: counting backward from 100 by sevens occupies enough of the mind to interrupt the loop. It doesn't matter if you get the numbers right."
        )),
        BookPage("The cold reset", listOf(
            "A sharp jolt of cold can break a wave by shocking the system and pulling your attention out of the spiral.",
            "Press an iced bottle to the back of your neck, or to your lower spine — many find that hits harder. Splashing cold water on your face works too.",
            "Keep it moving so it doesn't hurt the skin. Cold is one of the few switches that reaches the nervous system directly."
        )),
        BookPage("When medication shifts", listOf(
            "If medication that used to help is starting to slip, that is a signal to see your prescriber — not a failing on your part.",
            "When something long-standing needs more to do the same job, that's exactly the pattern prescribers watch for, and there are usually more options — a different medication, or one that treats the underlying overdrive rather than catching each wave.",
            "Medication catches the wave after it hits. Breathing and cold work on the front end, on the arousal that primes the next one. They aren't competitors — use both."
        )),
        BookPage("You deserve support", listOf(
            "Rolling waves are genuinely draining. Knowing they should pass while they keep coming back is its own kind of tired.",
            "If this is happening to you, please treat it as worth a real conversation with a doctor or therapist — not only an app. Rolling panic attacks respond very well to treatment, and a professional can look at your specific pattern in a way an app can't.",
            "If you're ever in an acute crisis, reach out: 988 in the US, or 116 123 across much of the EU. You built the habit of getting through this. You deserve the support too."
        ))
    ),
    settingsTitle = "Settings", settingsBack = "← Back",
    labLanguage = "LANGUAGE", labAppearance = "APPEARANCE",
    segDay = "Day", segNight = "Night", segAuto = "Auto", modeRow = "Day / Night",
    labColors = "COLORS", resetColors = "Reset colors to default", resetWord = "Reset",
    madeBy = "made by you, for you"
)

private val EL = L(
    hl = "Είσαι καλά.",
    sub = "Αυτό που νιώθεις είναι έντονο, αλλά όχι επικίνδυνο — και θα περάσει. Ανάπνευσε μαζί με τον κύκλο.",
    hint = "Μια πιο μακριά εκπνοή λέει στο σώμα σου ότι ο κίνδυνος πέρασε.",
    phases = listOf("Εισπνοή", "Κράτημα", "Εκπνοή"),
    groundTitle = "Προσγειώσου · 5-4-3-2-1",
    g5 = "πράγματα που βλέπεις γύρω σου", g4 = "πράγματα που μπορείς να αγγίξεις",
    g3 = "ήχους που ακούς", g2 = "πράγματα που μυρίζεις", g1 = "κάτι που γεύεσαι",
    groundHint = "Πήγαινε αργά. Πες τα δυνατά αν μπορείς.",
    wavesTitle = "Όταν τα κύματα συνεχίζουν να έρχονται",
    waves = listOf(
        "Ο πανικός μπορεί να έρχεται σε κύματα — ένα υποχωρεί, και χτίζεται το επόμενο. Είναι συχνό και δεν σημαίνει ότι κάτι πάει στραβά με σένα.",
        "Κάθε κύμα αφήνει το σώμα σε ετοιμότητα, κι έτσι μια γρήγορη καρδιά ή γρήγορη αναπνοή μπορεί να πυροδοτήσει το επόμενο. Η αργή αναπνοή σπάει αυτόν τον κύκλο.",
        "Η γρήγορη καρδιά στη διάρκεια του πανικού είναι η αδρεναλίνη που κάνει τη δουλειά της, όχι η καρδιά σου που αποτυγχάνει — ειδικά αν γιατρός σε έχει ελέγξει και σε βρήκε υγιή.",
        "Αν ένα φάρμακο που βοηθούσε αρχίζει να χάνει τη δύναμή του, αυτό είναι σήμα να δεις τον γιατρό που το συνταγογραφεί — όχι δική σου αποτυχία. Σχεδόν πάντα υπάρχουν κι άλλες επιλογές.",
        "Η εξάντληση μετά είναι ένα «χανγκόβερ αδρεναλίνης». Ξεκούραση, νερό και επιείκεια με τον εαυτό σου είναι η θεραπεία· περνάει."
    ),
    rememberTitle = "Θυμήσου",
    rem = listOf(
        "Ο πανικός συνήθως κορυφώνεται μέσα σε λίγα λεπτά και μετά ξεθωριάζει. Πάντα περνάει.",
        "Είναι ο συναγερμός του σώματός σου που χτυπάει κατά λάθος. Νιώθεις απαίσια, αλλά δεν σε βλάπτει.",
        "Μην πολεμάς το κύμα. Άφησέ το να ανέβει, να κορυφωθεί και να πέσει μόνο του.",
        "Το κρύο ταρακουνά το σύστημα και μπορεί να σπάσει το κύμα: πίεσε ένα παγωμένο μπουκάλι στον αυχένα ή στη βάση της σπονδυλικής στήλης — πολλοί βρίσκουν ότι εκεί πιάνει πιο δυνατά. Και το κρύο νερό στο πρόσωπο βοηθά. Κράτα το σε κίνηση για να μην πληγώσει το δέρμα."
    ),
    footer = "Οι κρίσεις πανικού είναι συχνές και αντιμετωπίζονται πολύ καλά. Αν συνεχίζονται, ένας γιατρός ή ψυχοθεραπευτής μπορεί πραγματικά να βοηθήσει.\n\nΠόνος στο στήθος που είναι καινούριος ή διαφορετικός για σένα; Είναι πάντα σωστό να ζητήσεις ιατρική φροντίδα — κάλεσε το 112. Για δωρεάν στήριξη, κάλεσε τη γραμμή 1018 (24ωρη).",
    playBack = "← Πίσω στην αναπνοή", playReset = "↩ Επαναφορά", playTitle = "Κάν' το δικό σου",
    playBlurb = "Το παιχνίδι με τα χρώματα ηρεμεί πραγματικά τον εγκέφαλο: η ήπια, απορροφητική επιλογή δημιουργεί ροή και ευχαρίστηση, και το να διαλέγεις μόνος σου επαναφέρει την αίσθηση ελέγχου, που μαλακώνει το στρες. Κάθε χρώμα εδώ διαλέχτηκε για ηρεμία — διάλεξε ελεύθερα, κάθε συνδυασμός είναι καλός. Κι αν κάτι δείχνει περίεργο, ένα άγγιγμα στην Επαναφορά τα φέρνει όλα πίσω. Δεν μπορείς να το χαλάσεις.",
    chooseTheme = "ΔΙΑΛΕΞΕ ΘΕΜΑ", mixOpen = "ΣΥΝΘΕΣΕ ΚΟΜΜΑΤΙΑ · ΠΡΟΑΙΡΕΤΙΚΟ ▲", mixClosed = "ΣΥΝΘΕΣΕ ΚΟΜΜΑΤΙΑ · ΠΡΟΑΙΡΕΤΙΚΟ ▼",
    labBg = "ΦΟΝΤΟ", labCards = "ΚΑΡΤΕΣ", labCircle = "ΚΥΚΛΟΣ ΑΝΑΠΝΟΗΣ", labAccent = "ΤΟΝΟΣ · ΤΙΤΛΟΙ & ΑΡΙΘΜΟΙ",
    labDepth = "ΟΛΟ ΤΟ ΘΕΜΑ · ΠΙΟ ΑΝΟΙΧΤΕΣ ΚΑΡΤΕΣ ← → ΠΙΟ ΣΚΟΥΡΟ ΟΛΟ (ΤΟ ΦΟΝΤΟ ΔΕΝ ΑΝΟΙΓΕΙ)",
    depthL2 = "+2", depthL1 = "+1", depthYours = "δικά σου", depthD1 = "−1", depthD2 = "−2",
    playNote = "Φτιαγμένο από σένα, για σένα — κι αυτή η ιδιοκτησία είναι μέρος του γιατί δουλεύει.",
    themeWord = "Θέμα:",
    contents = "☰ Περιεχόμενα", contentsClose = "Κλείσιμο", bookTitle = "Κατανοώντας τα κύματα", chapterWord = "Κεφάλαιο",
    bookPages = listOf(
        BookPage("Κυλιόμενες κρίσεις πανικού", listOf(
            "Αυτό που ίσως νιώθεις λέγεται συχνά κυλιόμενη κρίση πανικού — πολλαπλές κρίσεις που στοιβάζονται για ώρες, με τα όρια να θολώνουν, ώστε να μοιάζει με ένα αδιάκοπο κύμα αντί για ένα γεγονός που τελειώνει.",
            "Είναι μια αναγνωρισμένη εμπειρία, και ο λόγος που επιστρέφει είναι μηχανικός — όχι σημάδι ότι κάτι πάει ιατρικά στραβά.",
            "Το να ξέρεις ότι έχει όνομα, και αιτία, είναι το πρώτο βήμα για να του πάρεις λίγη από τη δύναμή του."
        )),
        BookPage("Ο βρόχος ανατροφοδότησης", listOf(
            "Η μηχανή πίσω του είναι ένας βρόχος ανατροφοδότησης. Μια κρίση πλημμυρίζει το σώμα με αδρεναλίνη και κορτιζόλη. Καθώς πέφτουν, τα συμπτώματα υποχωρούν για λίγο — αλλά σε αφήνουν σε αυξημένη διέγερση, ακόμα σε ετοιμότητα.",
            "Σε αυτή την κατάσταση, μια ελαφρώς γρήγορη καρδιά, μια μικρή ζάλη ή μια ρηχή αναπνοή διαβάζεται από τον εγκέφαλο ξανά ως κίνδυνος — και αυτή η ανάγνωση ξαναπυροδοτεί όλη την απόκριση «πάλης ή φυγής», ξεκινώντας το επόμενο κύμα.",
            "Έτσι, οι ίδιες οι αισθήσεις που αφήνει πίσω του ένα κύμα γίνονται η σκανδάλη για το επόμενο."
        )),
        BookPage("Γιατί το να παρακολουθείς τον εαυτό σου το τρέφει", listOf(
            "Μετά από μια κρίση είναι συνηθισμένο να αρχίζεις να παρακολουθείς το σώμα σου — να προσέχεις την αναπνοή και την καρδιά σου, σε αναμονή για την επόμενη.",
            "Αυτή η υπερεπαγρύπνηση είναι που κρατά το νευρικό σύστημα σε συναγερμό — και ακριβώς αυτό τρέφει τον κύκλο.",
            "Δεν είναι ελάττωμά σου. Είναι ο βρόχος που κάνει ό,τι κάνουν οι βρόχοι — και μπορεί να διακοπεί."
        )),
        BookPage("Το χανγκόβερ της αδρεναλίνης", listOf(
            "Αυτό που νιώθεις όταν τα κύματα επιτέλους σταματούν — εξάντληση, θολούρα, πόνοι, νεύρα για ώρες ή μέρες — είναι κάτι ξεχωριστό, που λέγεται καμιά φορά «χανγκόβερ αδρεναλίνης».",
            "Είναι το φυσικό κόστος του να τρέχεις σε πλήρη ισχύ έκτακτης ανάγκης, ξανά και ξανά. Δεν σημαίνει ότι κινδυνεύεις ακόμα.",
            "Ξεκούραση, νερό και επιείκεια με τον εαυτό σου είναι η θεραπεία. Περνάει."
        )),
        BookPage("Δεν φταις εσύ", listOf(
            "Γιατί κάποιοι έχουν κυλιόμενα κύματα και άλλοι μία μόνο κρίση δεν είναι πλήρως κατανοητό.",
            "Συνδέεται με ένα πιο ευαισθητοποιημένο νευρικό σύστημα, από συνδυασμό γενετικών, βιολογικών και περιβαλλοντικών παραγόντων.",
            "Τίποτα από αυτά δεν προέρχεται από κάτι που έκανες λάθος."
        )),
        BookPage("Σπάζοντας τον βρόχο", listOf(
            "Ο βρόχος μπορεί να διακοπεί, και αυτή η εφαρμογή στοχεύει ακριβώς στον μηχανισμό.",
            "Η αναπνοή μακραίνει την εκπνοή σου για να ρίξει τη διέγερση που ετοιμάζει το επόμενο κύμα. Για καρδιά που τρέχει, ακόμα πιο μακριά εκπνοή — περίπου έξι αργές αναπνοές το λεπτό — δουλεύει καλύτερα.",
            "Το 5-4-3-2-1 στρέφει την προσοχή προς τα έξω, σπάζοντας την εσωτερική «σάρωση» του σώματος που σε ξαναπυροδοτεί. Βοηθά και η αριθμητική: μέτρα ανάποδα από το 100 ανά επτά — απασχολεί αρκετό μυαλό ώστε να διακόψει τον βρόχο. Δεν πειράζει αν κάνεις λάθη στους αριθμούς."
        )),
        BookPage("Η επαναφορά με κρύο", listOf(
            "Ένα απότομο σοκ κρύου μπορεί να σπάσει ένα κύμα, ταρακουνώντας το σύστημα και τραβώντας την προσοχή σου έξω από τη δίνη.",
            "Πίεσε ένα παγωμένο μπουκάλι στον αυχένα, ή στη βάση της σπονδυλικής στήλης — πολλοί βρίσκουν ότι εκεί πιάνει πιο δυνατά. Και το κρύο νερό στο πρόσωπο βοηθά.",
            "Κράτα το σε κίνηση για να μην πληγώσει το δέρμα. Το κρύο είναι ένας από τους λίγους διακόπτες που φτάνουν κατευθείαν στο νευρικό σύστημα."
        )),
        BookPage("Όταν το φάρμακο αλλάζει", listOf(
            "Αν ένα φάρμακο που βοηθούσε αρχίζει να χάνει τη δύναμή του, αυτό είναι σήμα να δεις τον γιατρό που το συνταγογραφεί — όχι δική σου αποτυχία.",
            "Όταν κάτι μακροχρόνιο χρειάζεται περισσότερο για την ίδια δουλειά, αυτό ακριβώς το μοτίβο προσέχουν οι γιατροί — και συνήθως υπάρχουν κι άλλες επιλογές: διαφορετικό φάρμακο, ή ένα που αντιμετωπίζει την υποκείμενη υπερδιέγερση αντί να πιάνει κάθε κύμα ξεχωριστά.",
            "Το φάρμακο πιάνει το κύμα αφού χτυπήσει. Η αναπνοή και το κρύο δουλεύουν από πριν, στη διέγερση που ετοιμάζει το επόμενο. Δεν είναι αντίπαλοι — χρησιμοποίησε και τα δύο."
        )),
        BookPage("Αξίζεις στήριξη", listOf(
            "Τα κυλιόμενα κύματα είναι πραγματικά εξαντλητικά. Το να ξέρεις ότι θα έπρεπε να περνούν ενώ συνεχίζουν να γυρίζουν είναι μια δική του κούραση.",
            "Αν σου συμβαίνει, σε παρακαλώ αντιμετώπισέ το ως κάτι που αξίζει μια πραγματική συζήτηση με γιατρό ή ψυχοθεραπευτή — όχι μόνο μια εφαρμογή. Οι κυλιόμενες κρίσεις ανταποκρίνονται πολύ καλά στη θεραπεία, και ένας ειδικός βλέπει το δικό σου μοτίβο όπως μια εφαρμογή δεν μπορεί.",
            "Αν βρεθείς ποτέ σε οξεία κρίση, μίλησε σε κάποιον: γραμμή 1018 (24ωρη), ή 112 για έκτακτη ανάγκη. Έχτισες τη συνήθεια να τα βγάζεις πέρα. Αξίζεις και τη στήριξη."
        ))
    ),
    settingsTitle = "Ρυθμίσεις", settingsBack = "← Πίσω",
    labLanguage = "ΓΛΩΣΣΑ", labAppearance = "ΕΜΦΑΝΙΣΗ",
    segDay = "Μέρα", segNight = "Νύχτα", segAuto = "Αυτόματο", modeRow = "Μέρα / Νύχτα",
    labColors = "ΧΡΩΜΑΤΑ", resetColors = "Επαναφορά χρωμάτων", resetWord = "Επαναφορά",
    madeBy = "φτιαγμένο από σένα, για σένα"
)

private val DE = L(
    hl = "Du bist okay.",
    sub = "Was du fühlst, ist intensiv, aber nicht gefährlich — und es geht vorbei. Atme mit dem Kreis.",
    hint = "Ein längeres Ausatmen sagt deinem Körper: die Gefahr ist vorbei.",
    phases = listOf("Einatmen", "Halten", "Ausatmen"),
    groundTitle = "Erde dich · 5-4-3-2-1",
    g5 = "Dinge, die du um dich siehst", g4 = "Dinge, die du berühren kannst",
    g3 = "Geräusche, die du hörst", g2 = "Dinge, die du riechst", g1 = "etwas, das du schmeckst",
    groundHint = "Geh langsam vor. Sag sie laut, wenn du kannst.",
    wavesTitle = "Wenn die Wellen nicht aufhören",
    waves = listOf(
        "Panik kann in Wellen kommen — eine ebbt ab, die nächste baut sich auf. Das ist häufig und kein Zeichen, dass mit dir etwas nicht stimmt.",
        "Jede Welle lässt den Körper in Alarmbereitschaft zurück, sodass ein schneller Herzschlag oder schnelles Atmen die nächste auslösen kann. Langsames Atmen bricht diese Schleife.",
        "Ein schneller Herzschlag während der Panik ist Adrenalin, das seine Arbeit tut — nicht dein Herz, das versagt. Besonders beruhigend, wenn ein Arzt dich untersucht und für gesund befunden hat.",
        "Wenn ein Medikament, das geholfen hat, nachzulassen beginnt, ist das ein Signal, deinen Arzt aufzusuchen — kein Versagen deinerseits. Es gibt fast immer weitere Möglichkeiten.",
        "Die Erschöpfung danach ist ein Adrenalin-Kater. Ruhe, Wasser und Nachsicht mit dir selbst sind die Kur; es geht vorbei."
    ),
    rememberTitle = "Denk daran",
    rem = listOf(
        "Panik erreicht meist innerhalb weniger Minuten ihren Höhepunkt und klingt dann ab. Sie geht immer vorbei.",
        "Das ist der Alarm deines Körpers, der aus Versehen losgeht. Es fühlt sich furchtbar an, aber es schadet dir nicht.",
        "Kämpfe nicht gegen die Welle. Lass sie steigen, brechen und von selbst fallen.",
        "Kälte rüttelt das System wach und kann die Welle brechen: drücke eine eiskalte Flasche an den Nacken oder an die untere Wirbelsäule — viele finden, dort wirkt es stärker. Kaltes Wasser ins Gesicht hilft auch. Halte die Flasche in Bewegung, damit die Haut nicht leidet."
    ),
    footer = "Panikattacken sind häufig und sehr gut behandelbar. Wenn sie wiederkommen, kann ein Arzt oder Therapeut wirklich helfen.\n\nBrustschmerz, der neu oder anders ist? Es ist immer richtig, medizinische Hilfe zu suchen — wähle 112. Für kostenlose seelische Unterstützung: TelefonSeelsorge 0800 111 0 111, rund um die Uhr.",
    playBack = "← Zurück zum Atmen", playReset = "↩ Zurücksetzen", playTitle = "Mach es zu deinem",
    playBlurb = "Mit Farben zu spielen beruhigt das Gehirn wirklich: sanftes, versunkenes Wählen schafft Flow und Freude, und eigene Entscheidungen geben ein Gefühl von Kontrolle zurück, das Stress mildert. Jede Farbe hier wurde für Ruhe gewählt — wähle frei, jede Kombination ist eine gute. Und falls etwas seltsam aussieht: ein Tipp auf Zurücksetzen bringt alles zurück. Du kannst hier nichts kaputt machen.",
    chooseTheme = "WÄHLE DEIN THEMA", mixOpen = "TEILE MISCHEN · OPTIONAL ▲", mixClosed = "TEILE MISCHEN · OPTIONAL ▼",
    labBg = "HINTERGRUND", labCards = "KARTEN", labCircle = "ATEMKREIS", labAccent = "AKZENT · TITEL & ZAHLEN",
    labDepth = "GANZES THEMA · HELLERE KARTEN ← → ALLES DUNKLER (HINTERGRUND WIRD NIE HELLER)",
    depthL2 = "+2", depthL1 = "+1", depthYours = "deins", depthD1 = "−1", depthD2 = "−2",
    playNote = "Von dir gemacht, für dich — und genau dieses Eigene ist Teil dessen, warum es wirkt.",
    themeWord = "Thema:",
    contents = "☰ Inhalt", contentsClose = "Schließen", bookTitle = "Die Wellen verstehen", chapterWord = "Kapitel",
    bookPages = listOf(
        BookPage("Rollende Panikattacken", listOf(
            "Was du vielleicht erlebst, nennt man oft eine rollende Panikattacke — mehrere Attacken, die sich über Stunden stapeln, mit verschwimmenden Grenzen, sodass es sich wie eine unerbittliche Welle anfühlt statt wie ein Ereignis, das endet.",
            "Es ist eine anerkannte Erfahrung, und der Grund für ihr Wiederkehren ist mechanisch — kein Zeichen, dass medizinisch etwas nicht stimmt.",
            "Zu wissen, dass es einen Namen und eine Ursache hat, ist der erste Schritt, ihm etwas von seiner Macht zu nehmen."
        )),
        BookPage("Die Rückkopplungsschleife", listOf(
            "Der Motor dahinter ist eine Rückkopplungsschleife. Eine Attacke flutet den Körper mit Adrenalin und Cortisol. Wenn sie sinken, lassen die Symptome kurz nach — aber sie hinterlassen dich in erhöhter Erregung, weiter in Bereitschaft.",
            "In diesem Zustand liest das Gehirn einen leicht schnellen Herzschlag, leichten Schwindel oder flaches Atmen wieder als Gefahr — und diese Lesart zündet die gesamte Kampf-oder-Flucht-Reaktion neu und startet die nächste Welle.",
            "So werden genau die Empfindungen, die eine Welle zurücklässt, zum Auslöser der nächsten."
        )),
        BookPage("Warum Selbstbeobachtung es nährt", listOf(
            "Nach einer Attacke beginnt man oft, den eigenen Körper zu überwachen — Atem und Herzschlag zu beobachten, gefasst auf die nächste.",
            "Diese Hypervigilanz hält das Nervensystem in Alarmbereitschaft — und genau das nährt den Kreislauf.",
            "Es ist kein Fehler in dir. Es ist die Schleife, die tut, was Schleifen tun — und sie lässt sich unterbrechen."
        )),
        BookPage("Der Adrenalin-Kater", listOf(
            "Was du fühlst, wenn die Wellen endlich aufhören — Erschöpfung, Nebel im Kopf, Schmerzen, stunden- oder tagelange Anspannung — ist etwas Eigenes, das manchmal Adrenalin-Kater genannt wird.",
            "Es ist der natürliche Preis dafür, wiederholt mit voller Notfallkraft zu laufen. Es bedeutet nicht, dass du noch in Gefahr bist.",
            "Ruhe, Wasser und Nachsicht mit dir selbst sind die Kur. Es geht vorbei."
        )),
        BookPage("Es ist nicht deine Schuld", listOf(
            "Warum manche Menschen rollende Wellen bekommen und andere eine einzelne Attacke, ist nicht vollständig verstanden.",
            "Es hängt mit einem sensibilisierten Nervensystem zusammen, aus einer Mischung genetischer, biologischer und umweltbedingter Faktoren.",
            "Nichts davon kommt von etwas, das du falsch gemacht hast."
        )),
        BookPage("Die Schleife durchbrechen", listOf(
            "Die Schleife lässt sich unterbrechen, und diese App zielt genau auf den Mechanismus.",
            "Das Atmen verlängert dein Ausatmen, um die Erregung zu senken, die die nächste Welle vorbereitet. Bei rasendem Herzen wirkt ein noch längeres Ausatmen — etwa sechs langsame Atemzüge pro Minute — am besten.",
            "Das 5-4-3-2-1 lenkt die Aufmerksamkeit nach außen und bricht das innere Körper-Scannen, das dich neu zündet. Kopfrechnen hilft auch: Rückwärtszählen von 100 in Siebenerschritten beschäftigt genug vom Kopf, um die Schleife zu unterbrechen. Es ist egal, ob die Zahlen stimmen."
        )),
        BookPage("Der Kälte-Reset", listOf(
            "Ein scharfer Kältereiz kann eine Welle brechen, indem er das System wachrüttelt und deine Aufmerksamkeit aus der Spirale zieht.",
            "Drücke eine eiskalte Flasche an den Nacken oder an die untere Wirbelsäule — viele finden, dort wirkt es stärker. Kaltes Wasser ins Gesicht hilft auch.",
            "Halte sie in Bewegung, damit die Haut nicht leidet. Kälte ist einer der wenigen Schalter, die das Nervensystem direkt erreichen."
        )),
        BookPage("Wenn Medikamente sich verändern", listOf(
            "Wenn ein Medikament, das geholfen hat, nachzulassen beginnt, ist das ein Signal, deinen verschreibenden Arzt aufzusuchen — kein Versagen deinerseits.",
            "Wenn etwas Langjähriges mehr braucht für dieselbe Wirkung, ist das genau das Muster, auf das Ärzte achten — und es gibt meist weitere Möglichkeiten: ein anderes Medikament, oder eines, das die zugrunde liegende Übererregung behandelt, statt jede Welle einzeln abzufangen.",
            "Medikamente fangen die Welle ab, nachdem sie zuschlägt. Atmen und Kälte wirken davor, auf die Erregung, die die nächste vorbereitet. Sie sind keine Konkurrenten — nutze beides."
        )),
        BookPage("Du verdienst Unterstützung", listOf(
            "Rollende Wellen sind wirklich zermürbend. Zu wissen, dass sie vorbeigehen sollten, während sie wiederkommen, ist eine eigene Art von Müdigkeit.",
            "Wenn dir das passiert, behandle es bitte als etwas, das ein echtes Gespräch mit Arzt oder Therapeut verdient — nicht nur eine App. Rollende Panikattacken sprechen sehr gut auf Behandlung an, und eine Fachperson sieht dein Muster, wie eine App es nicht kann.",
            "Wenn du je in einer akuten Krise bist, melde dich: TelefonSeelsorge 0800 111 0 111, rund um die Uhr — oder 112 im Notfall. Du hast die Gewohnheit aufgebaut, da durchzukommen. Du verdienst auch die Unterstützung."
        ))
    ),
    settingsTitle = "Einstellungen", settingsBack = "← Zurück",
    labLanguage = "SPRACHE", labAppearance = "DARSTELLUNG",
    segDay = "Tag", segNight = "Nacht", segAuto = "Auto", modeRow = "Tag / Nacht",
    labColors = "FARBEN", resetColors = "Farben zurücksetzen", resetWord = "Zurücksetzen",
    madeBy = "von dir gemacht, für dich"
)

private val FR = L(
    hl = "Ça va aller.",
    sub = "Ce que tu ressens est intense, mais sans danger — et ça va passer. Respire avec le cercle.",
    hint = "Une expiration plus longue dit à ton corps que le danger est passé.",
    phases = listOf("Inspire", "Retiens", "Expire"),
    groundTitle = "Ancre-toi · 5-4-3-2-1",
    g5 = "choses que tu vois autour de toi", g4 = "choses que tu peux toucher",
    g3 = "sons que tu entends", g2 = "choses que tu sens", g1 = "chose que tu goûtes",
    groundHint = "Va lentement. Nomme-les à voix haute si tu peux.",
    wavesTitle = "Quand les vagues reviennent",
    waves = listOf(
        "La panique peut venir par vagues — l'une s'apaise, la suivante monte. C'est courant et ce n'est pas le signe que quelque chose ne va pas chez toi.",
        "Chaque vague laisse le corps en alerte : un cœur rapide ou une respiration rapide peut déclencher la suivante. Respirer lentement brise cette boucle.",
        "Un cœur qui bat vite pendant la panique, c'est l'adrénaline qui fait son travail — pas ton cœur qui lâche. D'autant plus rassurant si un médecin t'a examiné et t'a trouvé en bonne santé.",
        "Si un médicament qui aidait commence à faiblir, c'est un signal pour voir ton prescripteur — pas un échec de ta part. Il existe presque toujours d'autres options.",
        "L'épuisement d'après est une « gueule de bois d'adrénaline ». Repos, eau et douceur envers toi-même sont le remède ; ça passe."
    ),
    rememberTitle = "Rappelle-toi",
    rem = listOf(
        "La panique atteint généralement son pic en quelques minutes, puis s'estompe. Elle passe toujours.",
        "C'est l'alarme de ton corps qui se déclenche par erreur. C'est affreux à vivre, mais ça ne te fait pas de mal.",
        "Ne combats pas la vague. Laisse-la monter, culminer et retomber d'elle-même.",
        "Le froid secoue le système et peut briser la vague : presse une bouteille glacée sur la nuque, ou sur le bas de la colonne — beaucoup trouvent que c'est là que ça agit le plus fort. L'eau froide sur le visage aide aussi. Garde-la en mouvement pour ne pas abîmer la peau."
    ),
    footer = "Les crises de panique sont courantes et se soignent très bien. Si elles reviennent, un médecin ou un thérapeute peut vraiment aider.\n\nUne douleur dans la poitrine nouvelle ou différente ? Il est toujours juste de consulter — compose le 112. Pour un soutien gratuit, appelle le 3114, 24 h/24.",
    playBack = "← Retour à la respiration", playReset = "↩ Réinitialiser", playTitle = "Fais-le tien",
    playBlurb = "Jouer avec les couleurs apaise vraiment le cerveau : choisir doucement, en s'absorbant, crée du flow et du plaisir, et faire ses propres choix redonne un sentiment de contrôle qui adoucit le stress. Chaque couleur ici a été choisie pour le calme — choisis librement, chaque combinaison est bonne. Et si quelque chose semble étrange, un appui sur Réinitialiser ramène tout. Tu ne peux rien casser.",
    chooseTheme = "CHOISIS TON THÈME", mixOpen = "MÉLANGER LES PIÈCES · OPTIONNEL ▲", mixClosed = "MÉLANGER LES PIÈCES · OPTIONNEL ▼",
    labBg = "FOND", labCards = "CARTES", labCircle = "CERCLE DE RESPIRATION", labAccent = "ACCENT · TITRES & NOMBRES",
    labDepth = "THÈME ENTIER · CARTES PLUS CLAIRES ← → TOUT PLUS SOMBRE (LE FOND NE S'ÉCLAIRCIT JAMAIS)",
    depthL2 = "+2", depthL1 = "+1", depthYours = "les tiens", depthD1 = "−1", depthD2 = "−2",
    playNote = "Fait par toi, pour toi — et cette appartenance fait partie de ce qui le rend efficace.",
    themeWord = "Thème :",
    contents = "☰ Sommaire", contentsClose = "Fermer", bookTitle = "Comprendre les vagues", chapterWord = "Chapitre",
    bookPages = listOf(
        BookPage("Les crises de panique en vagues", listOf(
            "Ce que tu ressens peut-être s'appelle souvent une crise de panique en vagues — plusieurs crises qui s'empilent pendant des heures, aux frontières floues, si bien qu'on dirait une vague ininterrompue plutôt qu'un événement qui se termine.",
            "C'est une expérience reconnue, et la raison de son retour est mécanique — pas le signe d'un problème médical.",
            "Savoir que cela a un nom, et une cause, est le premier pas pour lui retirer un peu de son pouvoir."
        )),
        BookPage("La boucle de rétroaction", listOf(
            "Le moteur derrière tout ça est une boucle de rétroaction. Une crise inonde le corps d'adrénaline et de cortisol. Quand elles retombent, les symptômes s'apaisent un moment — mais elles te laissent dans un état d'alerte, encore amorcé.",
            "Dans cet état, un cœur un peu rapide, un léger vertige ou une respiration courte est relu par le cerveau comme un danger — et cette lecture relance toute la réponse de lutte ou de fuite, déclenchant la vague suivante.",
            "Ainsi, les sensations mêmes que laisse une vague deviennent le déclencheur de la suivante."
        )),
        BookPage("Pourquoi s'observer l'alimente", listOf(
            "Après une crise, il est courant de se mettre à surveiller son corps — guetter sa respiration et son cœur, prêt pour la prochaine.",
            "Cette hypervigilance maintient le système nerveux en alerte — et c'est précisément ce qui nourrit le cycle.",
            "Ce n'est pas un défaut chez toi. C'est la boucle qui fait ce que font les boucles — et elle peut être interrompue."
        )),
        BookPage("La gueule de bois d'adrénaline", listOf(
            "Ce que tu ressens quand les vagues s'arrêtent enfin — épuisement, brouillard mental, douleurs, nervosité pendant des heures ou des jours — est une chose à part, parfois appelée gueule de bois d'adrénaline.",
            "C'est le coût naturel de tourner à pleine puissance d'urgence, à répétition. Cela ne veut pas dire que tu es encore en danger.",
            "Repos, eau et douceur envers toi-même sont le remède. Ça passe."
        )),
        BookPage("Ce n'est pas ta faute", listOf(
            "Pourquoi certains ont des vagues successives et d'autres une seule crise n'est pas entièrement compris.",
            "C'est lié à un système nerveux plus sensibilisé, par un mélange de facteurs génétiques, biologiques et environnementaux.",
            "Rien de tout cela ne vient de quelque chose que tu aurais mal fait."
        )),
        BookPage("Briser la boucle", listOf(
            "La boucle peut être interrompue, et cette appli vise exactement le mécanisme.",
            "La respiration allonge ton expiration pour faire baisser l'alerte qui prépare la vague suivante. Pour un cœur qui s'emballe, une expiration encore plus longue — environ six respirations lentes par minute — marche le mieux.",
            "Le 5-4-3-2-1 tourne l'attention vers l'extérieur et brise le scan intérieur du corps qui te relance. Le calcul mental aide aussi : compter à rebours depuis 100 par sept occupe assez l'esprit pour interrompre la boucle. Peu importe si les nombres sont justes."
        )),
        BookPage("Le reset par le froid", listOf(
            "Un choc de froid net peut briser une vague en secouant le système et en tirant ton attention hors de la spirale.",
            "Presse une bouteille glacée sur la nuque, ou sur le bas de la colonne — beaucoup trouvent que c'est là que ça agit le plus fort. L'eau froide sur le visage aide aussi.",
            "Garde-la en mouvement pour ne pas abîmer la peau. Le froid est l'un des rares interrupteurs qui atteint directement le système nerveux."
        )),
        BookPage("Quand le médicament change", listOf(
            "Si un médicament qui aidait commence à faiblir, c'est un signal pour voir ton prescripteur — pas un échec de ta part.",
            "Quand quelque chose d'ancien demande plus pour le même effet, c'est exactement le schéma que surveillent les prescripteurs — et il existe généralement d'autres options : un autre médicament, ou un qui traite la suractivation de fond plutôt que d'attraper chaque vague.",
            "Le médicament attrape la vague après qu'elle frappe. La respiration et le froid agissent en amont, sur l'alerte qui prépare la suivante. Ils ne sont pas concurrents — utilise les deux."
        )),
        BookPage("Tu mérites du soutien", listOf(
            "Les vagues successives épuisent vraiment. Savoir qu'elles devraient passer alors qu'elles reviennent est une fatigue à part.",
            "Si cela t'arrive, considère que cela mérite une vraie conversation avec un médecin ou un thérapeute — pas seulement une appli. Les crises en vagues répondent très bien au traitement, et un professionnel peut lire ton schéma comme une appli ne le peut pas.",
            "Si tu traverses un jour une crise aiguë, parle à quelqu'un : le 3114, 24 h/24, ou le 112 en urgence. Tu as construit l'habitude de t'en sortir. Tu mérites aussi le soutien."
        ))
    ),
    settingsTitle = "Réglages", settingsBack = "← Retour",
    labLanguage = "LANGUE", labAppearance = "APPARENCE",
    segDay = "Jour", segNight = "Nuit", segAuto = "Auto", modeRow = "Jour / Nuit",
    labColors = "COULEURS", resetColors = "Réinitialiser les couleurs", resetWord = "Réinitialiser",
    madeBy = "fait par toi, pour toi"
)

private val ES = L(
    hl = "Estás bien.",
    sub = "Lo que sientes es intenso, pero no peligroso — y pasará. Respira con el círculo.",
    hint = "Una exhalación más larga le dice a tu cuerpo que el peligro pasó.",
    phases = listOf("Inhala", "Mantén", "Exhala"),
    groundTitle = "Conéctate · 5-4-3-2-1",
    g5 = "cosas que ves a tu alrededor", g4 = "cosas que puedes tocar",
    g3 = "sonidos que oyes", g2 = "cosas que hueles", g1 = "algo que saboreas",
    groundHint = "Ve despacio. Nómbralas en voz alta si puedes.",
    wavesTitle = "Cuando las olas siguen viniendo",
    waves = listOf(
        "El pánico puede venir en olas: una se calma y la siguiente crece. Es común y no significa que algo esté mal en ti.",
        "Cada ola deja el cuerpo en alerta, así que un corazón acelerado o una respiración rápida puede disparar la siguiente. Respirar despacio rompe ese ciclo.",
        "Un corazón rápido durante el pánico es la adrenalina haciendo su trabajo, no tu corazón fallando — especialmente tranquilizador si un médico te ha revisado y te ha encontrado sano.",
        "Si una medicación que ayudaba empieza a perder efecto, es una señal para ver a tu médico — no un fallo tuyo. Casi siempre hay más opciones.",
        "El agotamiento de después es una «resaca de adrenalina». Descanso, agua y ser amable contigo son la cura; pasa."
    ),
    rememberTitle = "Recuerda",
    rem = listOf(
        "El pánico suele alcanzar su pico en pocos minutos y luego se desvanece. Siempre pasa.",
        "Es la alarma de tu cuerpo sonando por error. Se siente horrible, pero no te está haciendo daño.",
        "No luches contra la ola. Déjala subir, romper y caer sola.",
        "El frío sacude el sistema y puede romper la ola: presiona una botella helada contra la nuca, o contra la base de la columna — muchos sienten que ahí golpea más fuerte. El agua fría en la cara también ayuda. Mantenla en movimiento para no dañar la piel."
    ),
    footer = "Los ataques de pánico son comunes y muy tratables. Si siguen ocurriendo, un médico o terapeuta puede ayudar de verdad.\n\n¿Dolor en el pecho nuevo o diferente? Siempre está bien buscar atención médica — marca 112. Para apoyo gratuito, llama al 024, las 24 horas.",
    playBack = "← Volver a respirar", playReset = "↩ Restablecer", playTitle = "Hazla tuya",
    playBlurb = "Jugar con los colores calma de verdad el cerebro: elegir con calma y absorción crea flujo y disfrute, y tomar tus propias decisiones devuelve una sensación de control que suaviza el estrés. Cada color aquí fue elegido para la calma — elige libremente, toda combinación es buena. Y si algo se ve raro, un toque en Restablecer lo devuelve todo. No puedes romper esto.",
    chooseTheme = "ELIGE TU TEMA", mixOpen = "MEZCLAR PIEZAS · OPCIONAL ▲", mixClosed = "MEZCLAR PIEZAS · OPCIONAL ▼",
    labBg = "FONDO", labCards = "TARJETAS", labCircle = "CÍRCULO DE RESPIRACIÓN", labAccent = "ACENTO · TÍTULOS Y NÚMEROS",
    labDepth = "TEMA ENTERO · TARJETAS MÁS CLARAS ← → TODO MÁS OSCURO (EL FONDO NUNCA SE ACLARA)",
    depthL2 = "+2", depthL1 = "+1", depthYours = "tuyos", depthD1 = "−1", depthD2 = "−2",
    playNote = "Hecho por ti, para ti — y esa pertenencia es parte de por qué funciona.",
    themeWord = "Tema:",
    contents = "☰ Índice", contentsClose = "Cerrar", bookTitle = "Entender las olas", chapterWord = "Capítulo",
    bookPages = listOf(
        BookPage("Ataques de pánico en oleadas", listOf(
            "Lo que quizá sientes se llama a menudo ataque de pánico en oleadas: varios ataques que se apilan durante horas, con los límites borrosos, de modo que parece una ola implacable en lugar de un episodio que termina.",
            "Es una experiencia reconocida, y la razón por la que vuelve es mecánica — no una señal de que algo esté mal médicamente.",
            "Saber que tiene nombre, y causa, es el primer paso para quitarle parte de su poder."
        )),
        BookPage("El bucle de retroalimentación", listOf(
            "El motor detrás es un bucle de retroalimentación. Un ataque inunda el cuerpo de adrenalina y cortisol. Al bajar, los síntomas se calman un momento — pero te dejan en un estado de alerta elevada, todavía preparado.",
            "En ese estado, un corazón algo rápido, un mareo leve o una respiración corta es leído por el cerebro otra vez como peligro — y esa lectura vuelve a encender toda la respuesta de lucha o huida, lanzando la siguiente ola.",
            "Así, las mismas sensaciones que deja una ola se convierten en el disparador de la siguiente."
        )),
        BookPage("Por qué vigilarte lo alimenta", listOf(
            "Después de un ataque es común empezar a vigilar tu propio cuerpo — observar tu respiración y tu corazón, en guardia para el próximo.",
            "Esa hipervigilancia mantiene el sistema nervioso en alerta — y eso es precisamente lo que alimenta el ciclo.",
            "No es un defecto tuyo. Es el bucle haciendo lo que hacen los bucles — y se puede interrumpir."
        )),
        BookPage("La resaca de adrenalina", listOf(
            "Lo que sientes cuando las olas por fin paran — agotamiento, niebla mental, dolores, estar en tensión horas o días — es algo aparte, a veces llamado resaca de adrenalina.",
            "Es el coste natural de funcionar a plena potencia de emergencia, una y otra vez. No significa que sigas en peligro.",
            "Descanso, agua y ser amable contigo son la cura. Pasa."
        )),
        BookPage("No es tu culpa", listOf(
            "Por qué algunas personas tienen olas sucesivas y otras un solo ataque no se entiende del todo.",
            "Se relaciona con un sistema nervioso más sensibilizado, por una mezcla de factores genéticos, biológicos y ambientales.",
            "Nada de eso viene de algo que hicieras mal."
        )),
        BookPage("Romper el bucle", listOf(
            "El bucle se puede interrumpir, y esta app apunta justo al mecanismo.",
            "La respiración alarga tu exhalación para bajar la alerta que prepara la siguiente ola. Para un corazón acelerado, una exhalación aún más larga — unas seis respiraciones lentas por minuto — funciona mejor.",
            "El 5-4-3-2-1 lleva la atención hacia fuera, rompiendo el escaneo interno del cuerpo que te vuelve a encender. El cálculo mental también ayuda: contar hacia atrás desde 100 de siete en siete ocupa suficiente mente para interrumpir el bucle. No importa si te equivocas en los números."
        )),
        BookPage("El reinicio con frío", listOf(
            "Un golpe seco de frío puede romper una ola sacudiendo el sistema y sacando tu atención de la espiral.",
            "Presiona una botella helada contra la nuca, o contra la base de la columna — muchos sienten que ahí golpea más fuerte. El agua fría en la cara también ayuda.",
            "Mantenla en movimiento para no dañar la piel. El frío es uno de los pocos interruptores que llega directo al sistema nervioso."
        )),
        BookPage("Cuando la medicación cambia", listOf(
            "Si una medicación que ayudaba empieza a perder efecto, es una señal para ver a tu médico — no un fallo tuyo.",
            "Cuando algo de años necesita más para el mismo efecto, ese es exactamente el patrón que los médicos vigilan — y suele haber más opciones: otra medicación, o una que trate la sobreactivación de fondo en vez de atrapar cada ola.",
            "La medicación atrapa la ola después de que golpea. La respiración y el frío trabajan antes, sobre la alerta que prepara la siguiente. No son rivales — usa ambos."
        )),
        BookPage("Mereces apoyo", listOf(
            "Las olas sucesivas agotan de verdad. Saber que deberían pasar mientras siguen volviendo es un cansancio propio.",
            "Si te está pasando, trátalo como algo que merece una conversación real con un médico o terapeuta — no solo una app. Los ataques en oleadas responden muy bien al tratamiento, y un profesional puede ver tu patrón como una app no puede.",
            "Si alguna vez estás en crisis aguda, habla con alguien: 024, las 24 horas, o 112 en emergencias. Construiste el hábito de salir adelante. También mereces el apoyo."
        ))
    ),
    settingsTitle = "Ajustes", settingsBack = "← Volver",
    labLanguage = "IDIOMA", labAppearance = "APARIENCIA",
    segDay = "Día", segNight = "Noche", segAuto = "Auto", modeRow = "Día / Noche",
    labColors = "COLORES", resetColors = "Restablecer colores", resetWord = "Restablecer",
    madeBy = "hecho por ti, para ti"
)

private val IT = L(
    hl = "Stai bene.",
    sub = "Quello che senti è intenso, ma non pericoloso — e passerà. Respira con il cerchio.",
    hint = "Un'espirazione più lunga dice al tuo corpo che il pericolo è passato.",
    phases = listOf("Inspira", "Trattieni", "Espira"),
    groundTitle = "Radicati · 5-4-3-2-1",
    g5 = "cose che vedi intorno a te", g4 = "cose che puoi toccare",
    g3 = "suoni che senti", g2 = "cose che odori", g1 = "qualcosa che assaggi",
    groundHint = "Vai piano. Nominale ad alta voce se puoi.",
    wavesTitle = "Quando le onde continuano ad arrivare",
    waves = listOf(
        "Il panico può arrivare a ondate: una si calma, la successiva cresce. È comune e non significa che ci sia qualcosa che non va in te.",
        "Ogni onda lascia il corpo in allerta, così un cuore veloce o un respiro rapido può innescare la successiva. Respirare lentamente spezza quel ciclo.",
        "Un battito veloce durante il panico è l'adrenalina che fa il suo lavoro, non il tuo cuore che cede — tanto più rassicurante se un medico ti ha controllato e trovato sano.",
        "Se un farmaco che aiutava comincia a perdere effetto, è un segnale per vedere il tuo medico — non un tuo fallimento. Quasi sempre ci sono altre opzioni.",
        "La stanchezza di dopo è una «sbornia di adrenalina». Riposo, acqua e gentilezza verso te stesso sono la cura; passa."
    ),
    rememberTitle = "Ricorda",
    rem = listOf(
        "Il panico di solito raggiunge il picco in pochi minuti, poi svanisce. Passa sempre.",
        "È l'allarme del tuo corpo che scatta per errore. Si sente malissimo, ma non ti sta facendo del male.",
        "Non combattere l'onda. Lasciala salire, rompersi e ricadere da sola.",
        "Il freddo scuote il sistema e può spezzare l'onda: premi una bottiglia ghiacciata sulla nuca, o alla base della colonna — molti trovano che lì colpisca più forte. Anche l'acqua fredda sul viso aiuta. Tienila in movimento per non far male alla pelle."
    ),
    footer = "Gli attacchi di panico sono comuni e molto trattabili. Se continuano, un medico o uno psicoterapeuta può aiutare davvero.\n\nDolore al petto nuovo o diverso? È sempre giusto cercare cure mediche — chiama il 112. Per supporto gratuito, Telefono Amico: 02 99 777.",
    playBack = "← Torna al respiro", playReset = "↩ Ripristina", playTitle = "Rendila tua",
    playBlurb = "Giocare con i colori calma davvero il cervello: scegliere con calma e assorbimento crea flusso e piacere, e fare le proprie scelte restituisce un senso di controllo che ammorbidisce lo stress. Ogni colore qui è stato scelto per la calma — scegli liberamente, ogni combinazione è buona. E se qualcosa sembra strano, un tocco su Ripristina riporta tutto com'era. Non puoi rompere niente.",
    chooseTheme = "SCEGLI IL TUO TEMA", mixOpen = "MISCHIA I PEZZI · FACOLTATIVO ▲", mixClosed = "MISCHIA I PEZZI · FACOLTATIVO ▼",
    labBg = "SFONDO", labCards = "SCHEDE", labCircle = "CERCHIO DEL RESPIRO", labAccent = "ACCENTO · TITOLI E NUMERI",
    labDepth = "TEMA INTERO · SCHEDE PIÙ CHIARE ← → TUTTO PIÙ SCURO (LO SFONDO NON SI SCHIARISCE MAI)",
    depthL2 = "+2", depthL1 = "+1", depthYours = "tuoi", depthD1 = "−1", depthD2 = "−2",
    playNote = "Fatta da te, per te — e quella appartenenza è parte del perché funziona.",
    themeWord = "Tema:",
    contents = "☰ Indice", contentsClose = "Chiudi", bookTitle = "Capire le onde", chapterWord = "Capitolo",
    bookPages = listOf(
        BookPage("Attacchi di panico a ondate", listOf(
            "Quello che forse stai vivendo si chiama spesso attacco di panico a ondate: più attacchi che si accumulano per ore, con confini sfumati, così da sembrare un'onda incessante invece di un episodio che finisce.",
            "È un'esperienza riconosciuta, e il motivo per cui torna è meccanico — non un segno che qualcosa non va dal punto di vista medico.",
            "Sapere che ha un nome, e una causa, è il primo passo per toglierle un po' del suo potere."
        )),
        BookPage("Il circuito di retroazione", listOf(
            "Il motore dietro è un circuito di retroazione. Un attacco inonda il corpo di adrenalina e cortisolo. Quando calano, i sintomi si attenuano per un momento — ma ti lasciano in uno stato di allerta elevata, ancora innescato.",
            "In quello stato, un battito un po' veloce, un lieve giramento o un respiro corto viene riletto dal cervello come pericolo — e quella lettura riaccende l'intera risposta di attacco o fuga, lanciando l'onda successiva.",
            "Così, proprio le sensazioni lasciate da un'onda diventano l'innesco della successiva."
        )),
        BookPage("Perché osservarti lo alimenta", listOf(
            "Dopo un attacco è comune iniziare a monitorare il proprio corpo — controllare respiro e battito, pronti per il prossimo.",
            "Quell'ipervigilanza tiene il sistema nervoso in allerta — ed è esattamente ciò che alimenta il ciclo.",
            "Non è un difetto in te. È il circuito che fa quello che fanno i circuiti — e può essere interrotto."
        )),
        BookPage("La sbornia di adrenalina", listOf(
            "Quello che senti quando le onde finalmente si fermano — sfinimento, nebbia mentale, dolori, tensione per ore o giorni — è una cosa a parte, a volte chiamata sbornia di adrenalina.",
            "È il costo naturale di girare a piena potenza d'emergenza, più volte. Non significa che sei ancora in pericolo.",
            "Riposo, acqua e gentilezza verso te stesso sono la cura. Passa."
        )),
        BookPage("Non è colpa tua", listOf(
            "Perché alcune persone hanno onde successive e altre un solo attacco non è del tutto chiaro.",
            "È legato a un sistema nervoso più sensibilizzato, per un insieme di fattori genetici, biologici e ambientali.",
            "Niente di tutto questo viene da qualcosa che hai fatto di sbagliato."
        )),
        BookPage("Spezzare il circuito", listOf(
            "Il circuito può essere interrotto, e questa app punta proprio al meccanismo.",
            "La respirazione allunga la tua espirazione per abbassare l'allerta che prepara l'onda successiva. Per un cuore che corre, un'espirazione ancora più lunga — circa sei respiri lenti al minuto — funziona meglio.",
            "Il 5-4-3-2-1 porta l'attenzione fuori, spezzando la scansione interna del corpo che ti riaccende. Aiuta anche il calcolo mentale: contare all'indietro da 100 per sette occupa abbastanza mente da interrompere il circuito. Non importa se sbagli i numeri."
        )),
        BookPage("Il reset col freddo", listOf(
            "Un colpo netto di freddo può spezzare un'onda scuotendo il sistema e tirando la tua attenzione fuori dalla spirale.",
            "Premi una bottiglia ghiacciata sulla nuca, o alla base della colonna — molti trovano che lì colpisca più forte. Anche l'acqua fredda sul viso aiuta.",
            "Tienila in movimento per non far male alla pelle. Il freddo è uno dei pochi interruttori che raggiunge direttamente il sistema nervoso."
        )),
        BookPage("Quando il farmaco cambia", listOf(
            "Se un farmaco che aiutava comincia a perdere effetto, è un segnale per vedere il tuo medico — non un tuo fallimento.",
            "Quando qualcosa di lunga data richiede di più per lo stesso effetto, è esattamente lo schema che i medici osservano — e di solito ci sono altre opzioni: un farmaco diverso, o uno che tratta l'iperattivazione di fondo invece di prendere ogni onda.",
            "Il farmaco prende l'onda dopo che colpisce. Respiro e freddo lavorano prima, sull'allerta che prepara la successiva. Non sono rivali — usali entrambi."
        )),
        BookPage("Meriti sostegno", listOf(
            "Le onde successive sfiancano davvero. Sapere che dovrebbero passare mentre continuano a tornare è una stanchezza a parte.",
            "Se ti sta succedendo, trattalo come qualcosa che merita una vera conversazione con un medico o uno psicoterapeuta — non solo un'app. Gli attacchi a ondate rispondono molto bene alle cure, e un professionista può leggere il tuo schema come un'app non può.",
            "Se mai ti trovi in una crisi acuta, parla con qualcuno: Telefono Amico 02 99 777, o 112 in emergenza. Hai costruito l'abitudine di attraversare tutto questo. Meriti anche il sostegno."
        ))
    ),
    settingsTitle = "Impostazioni", settingsBack = "← Indietro",
    labLanguage = "LINGUA", labAppearance = "ASPETTO",
    segDay = "Giorno", segNight = "Notte", segAuto = "Auto", modeRow = "Giorno / Notte",
    labColors = "COLORI", resetColors = "Ripristina i colori", resetWord = "Ripristina",
    madeBy = "fatta da te, per te"
)

val Translations: Map<String, L> = mapOf(
    "en" to EN, "el" to EL, "de" to DE, "fr" to FR, "es" to ES, "it" to IT
)

val LocalStrings = staticCompositionLocalOf { EN }
