package com.example.calmnow

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// ---------- Your twelve palettes, exactly as approved ----------

@Immutable
data class CalmPalette(
    val bgTop: Color,
    val bgBottom: Color,
    val text: Color,
    val dim: Color,
    val accent: Color,
    val cardBg: Color,
    val cardBorder: Color,
    val chipBg: Color,
    val chipText: Color,
    val orb: Color,
    val orbInnerAlpha: Float,
    val orbOuterAlpha: Float,
    val ring: Color,
    val footer: Color,
    val cardHint: Color
)

private val ThemeNames = listOf(
    "Sky", "Cream", "Off-White", "Mist", "Sage", "Blush",
    "Navy", "Slate", "Ev. Sage", "Forest", "Plum", "Ember"
)

private val AllThemes = listOf(
    CalmPalette(
        bgTop = Color(0xFFE9F2FA), bgBottom = Color(0xFFF4F7F0),
        text = Color(0xFF2E4257), dim = Color(0xFF74879D), accent = Color(0xFF4E79B0),
        cardBg = Color(0xFFE2EDF8), cardBorder = Color(0xFF4E79B0).copy(alpha = 0.15f),
        chipBg = Color(0xFF7BA483).copy(alpha = 0.22f), chipText = Color(0xFF55795F),
        orb = Color(0xFF76A0D4), orbInnerAlpha = 0.48f, orbOuterAlpha = 0.08f,
        ring = Color(0xFF4E79B0).copy(alpha = 0.28f),
        footer = Color(0xFF74879D).copy(alpha = 0.9f), cardHint = Color(0xFF74879D)
    ),
    CalmPalette(
        bgTop = Color(0xFFF7F2E8), bgBottom = Color(0xFFFBF7EF),
        text = Color(0xFF4A4238), dim = Color(0xFF93887A), accent = Color(0xFF7C8F6A),
        cardBg = Color(0xFFF4EEE1), cardBorder = Color(0xFF7C8F6A).copy(alpha = 0.25f),
        chipBg = Color(0xFF9AAB89).copy(alpha = 0.25f), chipText = Color(0xFF5C6E4C),
        orb = Color(0xFFA9BC94), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFF7C8F6A).copy(alpha = 0.35f),
        footer = Color(0xFF93887A).copy(alpha = 0.9f), cardHint = Color(0xFF93887A)
    ),
    CalmPalette(
        bgTop = Color(0xFFFBFAF7), bgBottom = Color(0xFFF5F2EA),
        text = Color(0xFF4C4A43), dim = Color(0xFF918D80), accent = Color(0xFF7E7A6C),
        cardBg = Color(0xFFEFEBDF), cardBorder = Color(0xFF7E7A6C).copy(alpha = 0.28f),
        chipBg = Color(0xFF7E7A6C).copy(alpha = 0.14f), chipText = Color(0xFF6E6A5C),
        orb = Color(0xFFD9D3C0), orbInnerAlpha = 0.55f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF7E7A6C).copy(alpha = 0.3f),
        footer = Color(0xFF918D80).copy(alpha = 0.9f), cardHint = Color(0xFF918D80)
    ),
    CalmPalette(
        bgTop = Color(0xFFEDF1F4), bgBottom = Color(0xFFF5F7F9),
        text = Color(0xFF38434E), dim = Color(0xFF7E8B98), accent = Color(0xFF5A7186),
        cardBg = Color(0xFFDBE2E8), cardBorder = Color(0xFF5A7186).copy(alpha = 0.25f),
        chipBg = Color(0xFF5A7186).copy(alpha = 0.15f), chipText = Color(0xFF4C6478),
        orb = Color(0xFFC9D2DA), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF5A7186).copy(alpha = 0.3f),
        footer = Color(0xFF7E8B98).copy(alpha = 0.9f), cardHint = Color(0xFF7E8B98)
    ),
    CalmPalette(
        bgTop = Color(0xFFEDF2E9), bgBottom = Color(0xFFF5F8F2),
        text = Color(0xFF3F4A3C), dim = Color(0xFF83907C), accent = Color(0xFF6B8261),
        cardBg = Color(0xFFDBE5D2), cardBorder = Color(0xFF6B8261).copy(alpha = 0.25f),
        chipBg = Color(0xFF6B8261).copy(alpha = 0.16f), chipText = Color(0xFF566B4D),
        orb = Color(0xFFC6D5B8), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF6B8261).copy(alpha = 0.3f),
        footer = Color(0xFF83907C).copy(alpha = 0.9f), cardHint = Color(0xFF83907C)
    ),
    CalmPalette(
        bgTop = Color(0xFFF6EFEC), bgBottom = Color(0xFFFAF5F2),
        text = Color(0xFF4E413C), dim = Color(0xFF97867F), accent = Color(0xFF9C7C72),
        cardBg = Color(0xFFEAE0DB), cardBorder = Color(0xFF9C7C72).copy(alpha = 0.25f),
        chipBg = Color(0xFF9C7C72).copy(alpha = 0.16f), chipText = Color(0xFF7E5F56),
        orb = Color(0xFFDFC9C0), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF9C7C72).copy(alpha = 0.3f),
        footer = Color(0xFF97867F).copy(alpha = 0.9f), cardHint = Color(0xFF97867F)
    ),
    CalmPalette(
        bgTop = Color(0xFF0D1726), bgBottom = Color(0xFF13233C),
        text = Color(0xFFE8EEF9), dim = Color(0xFF9FAFC8), accent = Color(0xFFAFC4F5),
        cardBg = Color(0xFF182A45), cardBorder = Color(0xFFAFC4F5).copy(alpha = 0.12f),
        chipBg = Color(0xFFAFC4F5).copy(alpha = 0.16f), chipText = Color(0xFFAFC4F5),
        orb = Color(0xFFAFC4F5), orbInnerAlpha = 0.48f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFAFC4F5).copy(alpha = 0.25f),
        footer = Color(0xFF9FAFC8).copy(alpha = 0.9f), cardHint = Color(0xFF9FAFC8)
    ),
    CalmPalette(
        bgTop = Color(0xFF26364D), bgBottom = Color(0xFF2E4059),
        text = Color(0xFFF0F5FC), dim = Color(0xFFB3C1D8), accent = Color(0xFFBDD0F7),
        cardBg = Color(0xFF3A4E6E), cardBorder = Color(0xFFBDD0F7).copy(alpha = 0.18f),
        chipBg = Color(0xFFBDD0F7).copy(alpha = 0.2f), chipText = Color(0xFFD3E0FA),
        orb = Color(0xFFBDD0F7), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFBDD0F7).copy(alpha = 0.3f),
        footer = Color(0xFFB3C1D8).copy(alpha = 0.9f), cardHint = Color(0xFFB3C1D8)
    ),
    CalmPalette(
        bgTop = Color(0xFF3B473E), bgBottom = Color(0xFF46544A),
        text = Color(0xFFF0F4EC), dim = Color(0xFFC0CCBA), accent = Color(0xFFCFDFC4),
        cardBg = Color(0xFF536354), cardBorder = Color(0xFFCFDFC4).copy(alpha = 0.2f),
        chipBg = Color(0xFFCFDFC4).copy(alpha = 0.22f), chipText = Color(0xFFDCE8D2),
        orb = Color(0xFFC6D8B9), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFCFDFC4).copy(alpha = 0.3f),
        footer = Color(0xFFC0CCBA).copy(alpha = 0.9f), cardHint = Color(0xFFC0CCBA)
    ),
    CalmPalette(
        bgTop = Color(0xFF1A4028), bgBottom = Color(0xFF225130),
        text = Color(0xFFF7FBF6), dim = Color(0xFFA9C4AC), accent = Color(0xFFD6EAC3),
        cardBg = Color(0xFF285E3A), cardBorder = Color(0xFFE0F0D2).copy(alpha = 0.18f),
        chipBg = Color(0xFFE0F0D2).copy(alpha = 0.16f), chipText = Color(0xFFD6EAC3),
        orb = Color(0xFFBCE2BF), orbInnerAlpha = 0.45f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFE0F0D2).copy(alpha = 0.28f),
        footer = Color(0xFFA9C4AC).copy(alpha = 0.9f), cardHint = Color(0xFFA9C4AC)
    ),
    CalmPalette(
        bgTop = Color(0xFF2D1F4D), bgBottom = Color(0xFF3B2A61),
        text = Color(0xFFFCFAFE), dim = Color(0xFFC0B4DC), accent = Color(0xFFD9CAF5),
        cardBg = Color(0xFF443376), cardBorder = Color(0xFFE6DBF8).copy(alpha = 0.18f),
        chipBg = Color(0xFFE6DBF8).copy(alpha = 0.18f), chipText = Color(0xFFE4DAF9),
        orb = Color(0xFFD8CAF5), orbInnerAlpha = 0.45f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFE6DBF8).copy(alpha = 0.28f),
        footer = Color(0xFFC0B4DC).copy(alpha = 0.9f), cardHint = Color(0xFFC0B4DC)
    ),
    CalmPalette(
        bgTop = Color(0xFF3E231D), bgBottom = Color(0xFF4F3024),
        text = Color(0xFFFAF4EF), dim = Color(0xFFCEAC99), accent = Color(0xFFF2BC9C),
        cardBg = Color(0xFF5E3C2C), cardBorder = Color(0xFFF5C8AE).copy(alpha = 0.18f),
        chipBg = Color(0xFFF5C8AE).copy(alpha = 0.16f), chipText = Color(0xFFF6CFB5),
        orb = Color(0xFFF0BD9D), orbInnerAlpha = 0.42f, orbOuterAlpha = 0.07f,
        ring = Color(0xFFF5C8AE).copy(alpha = 0.26f),
        footer = Color(0xFFCEAC99).copy(alpha = 0.9f), cardHint = Color(0xFFCEAC99)
    )
)

// ---------- Color math: lightness shifts + contrast guard ----------

private fun Color.toHsl(): FloatArray {
    val r = red; val g = green; val b = blue
    val max = maxOf(r, g, b); val min = minOf(r, g, b)
    var h = 0f; var s = 0f; val l = (max + min) / 2f
    if (max != min) {
        val d = max - min
        s = if (l > 0.5f) d / (2f - max - min) else d / (max + min)
        h = when (max) {
            r -> (g - b) / d + (if (g < b) 6f else 0f)
            g -> (b - r) / d + 2f
            else -> (r - g) / d + 4f
        } / 6f
    }
    return floatArrayOf(h, s, l)
}

private fun hslColor(h: Float, s: Float, l: Float): Color {
    if (s == 0f) return Color(l, l, l)
    val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
    val p = 2f * l - q
    fun channel(t0: Float): Float {
        var t = t0
        if (t < 0f) t += 1f
        if (t > 1f) t -= 1f
        return when {
            t < 1f / 6f -> p + (q - p) * 6f * t
            t < 1f / 2f -> q
            t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
            else -> p
        }
    }
    return Color(channel(h + 1f / 3f), channel(h), channel(h - 1f / 3f))
}

private fun Color.shiftLightness(deltaPercent: Float): Color {
    val hsl = toHsl()
    val l = (hsl[2] + deltaPercent / 100f).coerceIn(0f, 1f)
    return hslColor(hsl[0], hsl[1], l)
}

private fun contrastRatio(a: Color, b: Color): Float {
    val la = a.luminance(); val lb = b.luminance()
    return (maxOf(la, lb) + 0.05f) / (minOf(la, lb) + 0.05f)
}

// nudge fg away from bg until readable — no mix can break
private fun ensureContrast(start: Color, bg: Color, minRatio: Float): Color {
    var fg = start
    var tries = 0
    val dir = if (bg.luminance() > 0.45f) -4f else 4f
    while (contrastRatio(fg, bg) < minRatio && tries < 14) {
        fg = fg.shiftLightness(dir)
        tries++
    }
    return fg
}

// ---------- A mix: four picks + depth, composed into a full palette ----------

private data class Mix(val bg: Int, val card: Int, val orb: Int, val acc: Int, val depth: Int)

private fun defaultMix(nightSide: Boolean) =
    if (nightSide) Mix(6, 6, 6, 6, 0) else Mix(0, 0, 0, 0, 0)

private fun Mix.isMatchedTheme(): Boolean = bg == card && card == orb && orb == acc

private fun composeMix(mix: Mix): CalmPalette {
    val d = mix.depth.toFloat()
    val bgD = minOf(d, 0f)      // background may darken, NEVER lighten
    val inkD = minOf(d, 0f) / 2f
    val tBg = AllThemes[mix.bg]
    val tCard = AllThemes[mix.card]
    val tOrb = AllThemes[mix.orb]
    val tAcc = AllThemes[mix.acc]

    val bgTop = tBg.bgTop.shiftLightness(bgD)
    val bgBottom = tBg.bgBottom.shiftLightness(bgD)
    val cardBg = tCard.cardBg.shiftLightness(d)

    return CalmPalette(
        bgTop = bgTop,
        bgBottom = bgBottom,
        text = ensureContrast(tBg.text.shiftLightness(inkD), bgTop, 4.5f),
        dim = ensureContrast(tBg.dim.shiftLightness(inkD), bgTop, 3f),
        accent = ensureContrast(tAcc.accent.shiftLightness(inkD), cardBg, 3.4f),
        cardBg = cardBg,
        cardBorder = tCard.cardBorder.shiftLightness(d).copy(alpha = tCard.cardBorder.alpha),
        chipBg = tAcc.chipBg.shiftLightness(d).copy(alpha = tAcc.chipBg.alpha),
        chipText = ensureContrast(tAcc.chipText.shiftLightness(inkD), cardBg, 3.4f),
        orb = tOrb.orb.shiftLightness(d),
        orbInnerAlpha = tOrb.orbInnerAlpha,
        orbOuterAlpha = tOrb.orbOuterAlpha,
        ring = tOrb.ring.shiftLightness(d).copy(alpha = tOrb.ring.alpha),
        footer = ensureContrast(tBg.footer.copy(alpha = 1f).shiftLightness(inkD), bgTop, 3f).copy(alpha = 0.9f),
        cardHint = ensureContrast(tBg.cardHint.shiftLightness(inkD), cardBg, 3f)
    )
}

private val LocalPalette = staticCompositionLocalOf { AllThemes[6] }

// ---------- Prefs helpers ----------

private fun SharedPreferences.loadMix(nightSide: Boolean): Mix {
    val p = if (nightSide) "n_" else "d_"
    val def = defaultMix(nightSide)
    return Mix(
        bg = getInt(p + "bg", def.bg).coerceIn(0, AllThemes.lastIndex),
        card = getInt(p + "card", def.card).coerceIn(0, AllThemes.lastIndex),
        orb = getInt(p + "orb", def.orb).coerceIn(0, AllThemes.lastIndex),
        acc = getInt(p + "acc", def.acc).coerceIn(0, AllThemes.lastIndex),
        depth = getInt(p + "dep", 0).coerceIn(-8, 8)
    )
}

private fun SharedPreferences.saveMix(nightSide: Boolean, mix: Mix) {
    val p = if (nightSide) "n_" else "d_"
    edit().putInt(p + "bg", mix.bg).putInt(p + "card", mix.card)
        .putInt(p + "orb", mix.orb).putInt(p + "acc", mix.acc)
        .putInt(p + "dep", mix.depth).apply()
}

// ---------- Activity ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = getSharedPreferences("calm_now", Context.MODE_PRIVATE)
        setContent {
            val systemDark = isSystemInDarkTheme()
            var mode by remember { mutableIntStateOf(prefs.getInt("mode", -1)) } // -1 auto, 0 day, 1 night
            var langCode by remember { mutableStateOf(prefs.getString("lang", "en") ?: "en") }
            var dayMix by remember { mutableStateOf(prefs.loadMix(false)) }
            var nightMix by remember { mutableStateOf(prefs.loadMix(true)) }
            var showPlay by remember { mutableStateOf(false) }
            var showBook by remember { mutableStateOf(false) }
            var showSettings by remember { mutableStateOf(false) }

            val isNight = when (mode) { 0 -> false; 1 -> true; else -> systemDark }
            val mix = if (isNight) nightMix else dayMix
            val palette = composeMix(mix)
            val strings = Translations[langCode] ?: Translations["en"]!!
            val scheme = if (isNight) {
                darkColorScheme(primary = palette.accent, background = palette.bgTop, onBackground = palette.text)
            } else {
                lightColorScheme(primary = palette.accent, background = palette.bgTop, onBackground = palette.text)
            }

            fun updateMix(new: Mix) {
                if (isNight) { nightMix = new; prefs.saveMix(true, new) }
                else { dayMix = new; prefs.saveMix(false, new) }
            }

            BackHandler(enabled = showPlay || showBook || showSettings) {
                showPlay = false; showBook = false; showSettings = false
            }

            CompositionLocalProvider(
                LocalPalette provides palette,
                LocalStrings provides strings
            ) {
                MaterialTheme(colorScheme = scheme) {
                    when {
                        showSettings -> SettingsScreen(
                            langCode = langCode,
                            mode = mode,
                            onBack = { showSettings = false },
                            onLang = { code ->
                                langCode = code
                                prefs.edit().putString("lang", code).apply()
                            },
                            onMode = { m ->
                                mode = m
                                prefs.edit().putInt("mode", m).apply()
                            },
                            onResetColors = {
                                dayMix = defaultMix(false); prefs.saveMix(false, dayMix)
                                nightMix = defaultMix(true); prefs.saveMix(true, nightMix)
                            }
                        )
                        showBook -> BookScreen(onBack = { showBook = false })
                        showPlay -> PlayScreen(
                            mix = mix,
                            onBack = { showPlay = false },
                            onReset = { updateMix(defaultMix(isNight)) },
                            onMixChange = { updateMix(it) }
                        )
                        else -> CalmScreen(
                            isNight = isNight,
                            onToggleDayNight = {
                                val m = if (isNight) 0 else 1
                                mode = m
                                prefs.edit().putInt("mode", m).apply()
                            },
                            onOpenPlay = { showPlay = true },
                            onOpenBook = { showBook = true },
                            onOpenSettings = { showSettings = true }
                        )
                    }
                }
            }
        }
    }
}

// ---------- Page 1: the breathing screen ----------

@Composable
fun CalmScreen(
    isNight: Boolean,
    onToggleDayNight: () -> Unit,
    onOpenPlay: () -> Unit,
    onOpenBook: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val c = LocalPalette.current
    val s = LocalStrings.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            // responsive: phones get slightly smaller buttons; tablets keep 56dp
            val compact = maxWidth < 480.dp
            val btnSize = if (compact) 46.dp else 56.dp
            val btnGap = if (compact) 10.dp else 18.dp
            val glyphSmall = if (compact) 17.sp else 22.sp
            val glyphBig = if (compact) 19.sp else 24.sp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Controls live IN the page flow — they can never cover the headline.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RoundButton(glyph = "\ud83d\udcd6", size = btnSize, glyphSize = glyphSmall, onClick = onOpenBook)
                    Spacer(Modifier.width(btnGap))
                    RoundButton(glyph = "\ud83c\udfa8", size = btnSize, glyphSize = glyphSmall, onClick = onOpenPlay)
                    Spacer(Modifier.width(btnGap))
                    RoundButton(glyph = "\u2699\ufe0f", size = btnSize, glyphSize = glyphSmall, onClick = onOpenSettings)
                    Spacer(Modifier.width(btnGap))
                    RoundButton(
                        glyph = if (isNight) "\u2600\ufe0f" else "\ud83c\udf19",
                        size = btnSize, glyphSize = glyphBig, onClick = onToggleDayNight
                    )
                }

                Spacer(Modifier.height(14.dp))

                Text(
                    text = s.hl,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.text,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = s.sub,
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                    color = c.dim,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(28.dp))
                BreathingCircle()
                Spacer(Modifier.height(10.dp))
                Text(
                    text = s.hint,
                    fontSize = 14.sp,
                    color = c.dim,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(32.dp))
                SectionCard(title = s.groundTitle) {
                    GroundingRow("5", s.g5)
                    GroundingRow("4", s.g4)
                    GroundingRow("3", s.g3)
                    GroundingRow("2", s.g2)
                    GroundingRow("1", s.g1)
                    Spacer(Modifier.height(8.dp))
                    Text(text = s.groundHint, fontSize = 14.sp, color = c.cardHint)
                }

                Spacer(Modifier.height(16.dp))
                SectionCard(title = s.wavesTitle) {
                    s.waves.forEach { ReassuranceLine(it) }
                }

                Spacer(Modifier.height(16.dp))
                SectionCard(title = s.rememberTitle) {
                    s.rem.forEach { ReassuranceLine(it) }
                }

                Spacer(Modifier.height(28.dp))
                Text(
                    text = s.footer,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = c.footer,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun RoundButton(glyph: String, size: Dp, glyphSize: TextUnit, onClick: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(c.cardBg)
            .border(1.dp, c.ring, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = glyph, fontSize = glyphSize)
    }
}

// ---------- Page 2: Make it yours ----------

@Composable
private fun PlayScreen(mix: Mix, onBack: () -> Unit, onReset: () -> Unit, onMixChange: (Mix) -> Unit) {
    val c = LocalPalette.current
    val s = LocalStrings.current
    var mixOpen by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Pill(text = s.playBack, onClick = onBack)
                Pill(text = s.playReset, onClick = onReset)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                text = s.playTitle,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = s.playBlurb,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(14.dp))
            PreviewPanel(mix)

            Spacer(Modifier.height(18.dp))
            Text(text = s.chooseTheme, fontSize = 11.sp, letterSpacing = 2.sp, color = c.dim)
            Spacer(Modifier.height(8.dp))
            ThemeNames.indices.chunked(3).forEach { rowIdx ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowIdx.forEach { i ->
                        ThemeTile(
                            index = i,
                            selected = mix.isMatchedTheme() && mix.bg == i,
                            modifier = Modifier.weight(1f)
                        ) { onMixChange(Mix(i, i, i, i, mix.depth)) }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            Spacer(Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, c.ring, RoundedCornerShape(12.dp))
                    .clickable { mixOpen = !mixOpen }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (mixOpen) s.mixOpen else s.mixClosed,
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    color = c.dim
                )
            }

            if (mixOpen) {
                MixSection(s.labBg, kind = 0, selected = mix.bg) { onMixChange(mix.copy(bg = it)) }
                MixSection(s.labCards, kind = 1, selected = mix.card) { onMixChange(mix.copy(card = it)) }
                MixSection(s.labCircle, kind = 2, selected = mix.orb) { onMixChange(mix.copy(orb = it)) }
                MixSection(s.labAccent, kind = 3, selected = mix.acc) { onMixChange(mix.copy(acc = it)) }

                Spacer(Modifier.height(14.dp))
                Text(text = s.labDepth, fontSize = 9.sp, letterSpacing = 1.5.sp, color = c.dim)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        8 to s.depthL2, 4 to s.depthL1, 0 to s.depthYours,
                        -4 to s.depthD1, -8 to s.depthD2
                    ).forEach { (d, label) ->
                        DepthChip(mix = mix, depth = d, label = label, selected = mix.depth == d) {
                            onMixChange(mix.copy(depth = d))
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                text = s.playNote,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = c.footer,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(c.cardBg)
            .border(1.5.dp, c.ring, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Text(text = text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.text)
    }
}

@Composable
private fun PreviewPanel(mix: Mix) {
    val c = LocalPalette.current
    val s = LocalStrings.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, c.cardBorder, RoundedCornerShape(16.dp))
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(s.hl, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.text)
        Spacer(Modifier.height(6.dp))
        BreathingCircle(circleSize = 140.dp, compact = true)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(c.cardBg)
                .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text(s.groundTitle, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c.accent)
            Spacer(Modifier.height(4.dp))
            MiniRow("5", s.g5)
            MiniRow("4", s.g4)
        }
        Spacer(Modifier.height(6.dp))
        val name = if (mix.isMatchedTheme()) s.themeWord + " " + ThemeNames[mix.bg]
        else ThemeNames[mix.bg] + " · " + ThemeNames[mix.card] + " · " +
                ThemeNames[mix.orb] + " · " + ThemeNames[mix.acc]
        val depthNote = when {
            mix.depth > 0 -> " · +" + (mix.depth / 4)
            mix.depth < 0 -> " · " + (mix.depth / 4)
            else -> ""
        }
        Text(name + depthNote, fontSize = 10.sp, color = c.dim, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MiniRow(number: String, text: String) {
    val c = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .background(c.chipBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = c.chipText, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(text, color = c.text, fontSize = 11.sp)
    }
}

@Composable
private fun ThemeTile(index: Int, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalPalette.current
    val t = AllThemes[index]
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        0f to t.bgTop, 0.55f to t.bgTop,
                        0.55f to t.cardBg, 1f to t.cardBg
                    )
                )
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) c.text else c.ring,
                    shape = RoundedCornerShape(12.dp)
                )
                .clickable(onClick = onClick)
        )
        Spacer(Modifier.height(3.dp))
        Text(ThemeNames[index], fontSize = 11.sp, fontWeight = FontWeight.Medium, color = c.text)
    }
}

@Composable
private fun MixSection(label: String, kind: Int, selected: Int, onPick: (Int) -> Unit) {
    val c = LocalPalette.current
    Spacer(Modifier.height(14.dp))
    Text(text = label, fontSize = 10.sp, letterSpacing = 2.sp, color = c.dim)
    Spacer(Modifier.height(6.dp))
    AllThemes.indices.chunked(6).forEach { row ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            row.forEach { i ->
                val t = AllThemes[i]
                val swatch = when (kind) {
                    0 -> t.bgTop
                    1 -> t.cardBg
                    2 -> t.orb
                    else -> t.accent
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(swatch)
                            .border(
                                width = if (selected == i) 3.dp else 1.dp,
                                color = if (selected == i) c.text else c.ring,
                                shape = RoundedCornerShape(9.dp)
                            )
                            .clickable { onPick(i) }
                    )
                    Text(ThemeNames[i], fontSize = 8.sp, color = c.dim)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun DepthChip(mix: Mix, depth: Int, label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalPalette.current
    val bgPrev = AllThemes[mix.bg].bgTop.shiftLightness(minOf(depth, 0).toFloat())
    val cardPrev = AllThemes[mix.card].cardBg.shiftLightness(depth.toFloat())
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(width = 52.dp, height = 30.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(
                    Brush.verticalGradient(
                        0f to bgPrev, 0.5f to bgPrev,
                        0.5f to cardPrev, 1f to cardPrev
                    )
                )
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) c.text else c.ring,
                    shape = RoundedCornerShape(8.dp)
                )
                .clickable(onClick = onClick)
        )
        Text(label, fontSize = 8.sp, color = c.dim)
    }
}

// ---------- Page 3: Understanding — a little book you swipe through ----------

@Composable
fun BookScreen(onBack: () -> Unit) {
    val c = LocalPalette.current
    val s = LocalStrings.current
    var showContents by remember { mutableStateOf(false) }
    val pagerState = rememberPagerState(pageCount = { s.bookPages.size })
    val rememberScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            val wide = maxWidth > 600.dp
            val colWidth = if (wide) 640.dp else maxWidth
            val hPad = if (wide) 24.dp else 18.dp
            val bodyText = if (wide) 18.sp else 16.sp
            val bodyLine = if (wide) 30.sp else 26.sp

            Column(
                modifier = Modifier
                    .widthIn(max = colWidth)
                    .fillMaxSize()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = hPad, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Pill(text = s.playBack, onClick = onBack)
                    Pill(
                        text = if (showContents) s.contentsClose else s.contents,
                        onClick = { showContents = !showContents }
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = s.bookTitle,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.text
                )
                Spacer(Modifier.height(12.dp))

                if (showContents) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        s.bookPages.forEachIndexed { i, p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(c.cardBg)
                                    .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
                                    .clickable {
                                        showContents = false
                                        rememberScope.launch { pagerState.animateScrollToPage(i) }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${i + 1}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = c.accent,
                                    modifier = Modifier.width(26.dp)
                                )
                                Text(text = p.title, fontSize = 15.sp, color = c.text)
                            }
                        }
                    }
                } else {
                    // The pages: a real swipeable book. Drag left/right to flip.
                    // Arrows live in their own side gutters — they can never cover the words.
                    val arrowSize = if (wide) 48.dp else 38.dp
                    val gutter = arrowSize + 6.dp
                    Row(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.width(gutter).fillMaxHeight(),
                            contentAlignment = Alignment.Center
                        ) {
                            NavArrow(
                                label = "\u2039",
                                enabled = pagerState.currentPage > 0,
                                size = arrowSize,
                                onClick = { rememberScope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } }
                            )
                        }
                        HorizontalPager(
                            state = pagerState,
                            modifier = Modifier.weight(1f).fillMaxHeight()
                        ) { pIdx ->
                            val bookPage = s.bookPages[pIdx]
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(c.cardBg)
                                    .border(1.dp, c.cardBorder, RoundedCornerShape(20.dp))
                                    .padding(horizontal = if (wide) 24.dp else 16.dp, vertical = 24.dp)
                            ) {
                                Text(
                                    text = s.chapterWord + " ${pIdx + 1}",
                                    fontSize = 11.sp,
                                    letterSpacing = 2.sp,
                                    color = c.dim
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = bookPage.title,
                                    fontFamily = FontFamily.Serif,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = c.accent,
                                    lineHeight = 30.sp
                                )
                                Spacer(Modifier.height(18.dp))
                                bookPage.paragraphs.forEach { para ->
                                    Text(
                                        text = para,
                                        fontFamily = FontFamily.Serif,
                                        fontSize = bodyText,
                                        lineHeight = bodyLine,
                                        color = c.text
                                    )
                                    Spacer(Modifier.height(16.dp))
                                }
                            }
                        }
                        Box(
                            modifier = Modifier.width(gutter).fillMaxHeight(),
                            contentAlignment = Alignment.Center
                        ) {
                            NavArrow(
                                label = "\u203a",
                                enabled = pagerState.currentPage < s.bookPages.lastIndex,
                                size = arrowSize,
                                onClick = { rememberScope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } }
                            )
                        }
                    }

                    // Page dots below
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            s.bookPages.indices.forEach { i ->
                                Box(
                                    modifier = Modifier
                                        .size(if (i == pagerState.currentPage) 9.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(if (i == pagerState.currentPage) c.accent else c.dim.copy(alpha = 0.4f))
                                        .clickable { rememberScope.launch { pagerState.animateScrollToPage(i) } }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
private fun NavArrow(label: String, enabled: Boolean, size: Dp, onClick: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .then(
                if (enabled) Modifier
                    .background(c.cardBg.copy(alpha = 0.92f))
                    .border(1.dp, c.ring, CircleShape)
                else Modifier
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 24.sp,
            fontWeight = FontWeight.Medium,
            color = if (enabled) c.accent else c.dim.copy(alpha = 0.25f)
        )
    }
}

// ---------- Page 4: Settings ----------

@Composable
fun SettingsScreen(
    langCode: String,
    mode: Int,
    onBack: () -> Unit,
    onLang: (String) -> Unit,
    onMode: (Int) -> Unit,
    onResetColors: () -> Unit
) {
    val c = LocalPalette.current
    val s = LocalStrings.current
    var ddOpen by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Pill(text = s.settingsBack, onClick = onBack)
                Pill(text = "\u2699\ufe0f", onClick = {})
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = s.settingsTitle,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))
            Text(text = s.labLanguage, fontSize = 10.sp, letterSpacing = 2.sp, color = c.dim)
            Spacer(Modifier.height(6.dp))

            // language drop-down
            val current = LangOptions.firstOrNull { it.first == langCode } ?: LangOptions[0]
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.cardBg)
                    .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { ddOpen = !ddOpen }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = current.second, fontSize = 17.sp)
                        Spacer(Modifier.width(9.dp))
                        Text(text = current.third, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.text)
                    }
                    Text(text = if (ddOpen) "\u25b4" else "\u25be", fontSize = 13.sp, color = c.dim)
                }
                if (ddOpen) {
                    LangOptions.forEach { (code, flag, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    ddOpen = false
                                    onLang(code)
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = flag, fontSize = 17.sp)
                                Spacer(Modifier.width(9.dp))
                                Text(
                                    text = name,
                                    fontSize = 14.sp,
                                    fontWeight = if (code == langCode) FontWeight.Bold else FontWeight.Normal,
                                    color = c.text
                                )
                            }
                            if (code == langCode) {
                                Text(text = "\u2713", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = c.accent)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(text = s.labAppearance, fontSize = 10.sp, letterSpacing = 2.sp, color = c.dim)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.cardBg)
                    .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "\ud83c\udf19 " + s.modeRow,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.text
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SegButton(text = s.segDay, selected = mode == 0) { onMode(0) }
                    SegButton(text = s.segNight, selected = mode == 1) { onMode(1) }
                    SegButton(text = s.segAuto, selected = mode == -1) { onMode(-1) }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(text = s.labColors, fontSize = 10.sp, letterSpacing = 2.sp, color = c.dim)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.cardBg)
                    .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "\ud83c\udfa8 " + s.resetColors,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.text
                )
                Text(
                    text = s.resetWord,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.accent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .clickable(onClick = onResetColors)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            Spacer(Modifier.height(22.dp))
            Text(
                text = "Calm Now \u00b7 v2.6 \u00b7 " + s.madeBy,
                fontSize = 10.sp,
                color = c.footer,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SegButton(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (selected) c.chipBg else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) c.ring else Color.Transparent,
                shape = RoundedCornerShape(999.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) c.chipText else c.dim
        )
    }
}

// ---------- Breathing guide (4 in · 4 hold · 6 out) ----------

private enum class BreathPhase(val idx: Int, val seconds: Int, val targetScale: Float) {
    Inhale(0, 4, 1f),
    Hold(1, 4, 1f),
    Exhale(2, 6, 0.55f)
}

@Composable
private fun BreathingCircle(
    modifier: Modifier = Modifier,
    circleSize: Dp = 280.dp,
    compact: Boolean = false
) {
    val c = LocalPalette.current
    val s = LocalStrings.current
    var phase by remember { mutableStateOf(BreathPhase.Inhale) }
    var count by remember { mutableIntStateOf(BreathPhase.Inhale.seconds) }
    val scale = remember { Animatable(BreathPhase.Exhale.targetScale) }

    LaunchedEffect(Unit) {
        while (isActive) {
            for (p in BreathPhase.entries) {
                phase = p
                count = p.seconds
                coroutineScope {
                    launch {
                        scale.animateTo(
                            targetValue = p.targetScale,
                            animationSpec = tween(
                                durationMillis = p.seconds * 1000,
                                easing = FastOutSlowInEasing
                            )
                        )
                    }
                    launch {
                        repeat(p.seconds) { i ->
                            count = p.seconds - i
                            delay(1000L)
                        }
                    }
                }
            }
        }
    }

    Box(modifier = modifier.size(circleSize), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .matchParentSize()
                .border(1.5.dp, c.ring, CircleShape)
        )
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .background(
                    Brush.radialGradient(
                        listOf(
                            c.orb.copy(alpha = c.orbInnerAlpha),
                            c.orb.copy(alpha = c.orbOuterAlpha)
                        )
                    ),
                    CircleShape
                )
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = s.phases[phase.idx],
                fontSize = if (compact) 12.sp else 22.sp,
                fontWeight = FontWeight.Medium,
                color = c.text
            )
            Spacer(Modifier.height(if (compact) 2.dp else 4.dp))
            Text(
                text = count.toString(),
                fontSize = if (compact) 20.sp else 44.sp,
                fontWeight = FontWeight.Light,
                color = c.text.copy(alpha = 0.9f)
            )
        }
    }
}

// ---------- Small building blocks ----------

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(c.cardBg, RoundedCornerShape(20.dp))
            .border(1.dp, c.cardBorder, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.accent
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun GroundingRow(number: String, text: String) {
    val c = LocalPalette.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(c.chipBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = c.chipText,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 16.sp,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun ReassuranceLine(text: String) {
    val c = LocalPalette.current
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Text(text = "\u00b7", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 15.sp,
            lineHeight = 22.sp
        )
    }
}
