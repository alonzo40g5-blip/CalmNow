package com.example.calmnow

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// ---------- Your twelve palettes, exactly as approved ----------

@Immutable
data class CalmPalette(
    val bgTop: Color,
    val bgBottom: Color,
    val text: Color,
    val dim: Color,
    val accent: Color,
    val cardBg: Color,
    val cardBorder: Color,
    val chipBg: Color,
    val chipText: Color,
    val orb: Color,
    val orbInnerAlpha: Float,
    val orbOuterAlpha: Float,
    val ring: Color,
    val footer: Color,
    val cardHint: Color
)

private val DayThemes = listOf(
    // Day 1 · Sky
    CalmPalette(
        bgTop = Color(0xFFE9F2FA), bgBottom = Color(0xFFF4F7F0),
        text = Color(0xFF2E4257), dim = Color(0xFF74879D), accent = Color(0xFF4E79B0),
        cardBg = Color(0xFFE2EDF8), cardBorder = Color(0xFF4E79B0).copy(alpha = 0.15f),
        chipBg = Color(0xFF7BA483).copy(alpha = 0.22f), chipText = Color(0xFF55795F),
        orb = Color(0xFF76A0D4), orbInnerAlpha = 0.48f, orbOuterAlpha = 0.08f,
        ring = Color(0xFF4E79B0).copy(alpha = 0.28f),
        footer = Color(0xFF74879D).copy(alpha = 0.9f), cardHint = Color(0xFF74879D)
    ),
    // Day 3 · Warm Cream
    CalmPalette(
        bgTop = Color(0xFFF7F2E8), bgBottom = Color(0xFFFBF7EF),
        text = Color(0xFF4A4238), dim = Color(0xFF93887A), accent = Color(0xFF7C8F6A),
        cardBg = Color(0xFFF4EEE1), cardBorder = Color(0xFF7C8F6A).copy(alpha = 0.25f),
        chipBg = Color(0xFF9AAB89).copy(alpha = 0.25f), chipText = Color(0xFF5C6E4C),
        orb = Color(0xFFA9BC94), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFF7C8F6A).copy(alpha = 0.35f),
        footer = Color(0xFF93887A).copy(alpha = 0.9f), cardHint = Color(0xFF93887A)
    ),
    // Day 4 · Off-White
    CalmPalette(
        bgTop = Color(0xFFFBFAF7), bgBottom = Color(0xFFF5F2EA),
        text = Color(0xFF4C4A43), dim = Color(0xFF918D80), accent = Color(0xFF7E7A6C),
        cardBg = Color(0xFFEFEBDF), cardBorder = Color(0xFF7E7A6C).copy(alpha = 0.28f),
        chipBg = Color(0xFF7E7A6C).copy(alpha = 0.14f), chipText = Color(0xFF6E6A5C),
        orb = Color(0xFFD9D3C0), orbInnerAlpha = 0.55f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF7E7A6C).copy(alpha = 0.3f),
        footer = Color(0xFF918D80).copy(alpha = 0.9f), cardHint = Color(0xFF918D80)
    ),
    // Day 5 · Mist
    CalmPalette(
        bgTop = Color(0xFFEDF1F4), bgBottom = Color(0xFFF5F7F9),
        text = Color(0xFF38434E), dim = Color(0xFF7E8B98), accent = Color(0xFF5A7186),
        cardBg = Color(0xFFDBE2E8), cardBorder = Color(0xFF5A7186).copy(alpha = 0.25f),
        chipBg = Color(0xFF5A7186).copy(alpha = 0.15f), chipText = Color(0xFF4C6478),
        orb = Color(0xFFC9D2DA), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF5A7186).copy(alpha = 0.3f),
        footer = Color(0xFF7E8B98).copy(alpha = 0.9f), cardHint = Color(0xFF7E8B98)
    ),
    // Day 6 · Soft Sage
    CalmPalette(
        bgTop = Color(0xFFEDF2E9), bgBottom = Color(0xFFF5F8F2),
        text = Color(0xFF3F4A3C), dim = Color(0xFF83907C), accent = Color(0xFF6B8261),
        cardBg = Color(0xFFDBE5D2), cardBorder = Color(0xFF6B8261).copy(alpha = 0.25f),
        chipBg = Color(0xFF6B8261).copy(alpha = 0.16f), chipText = Color(0xFF566B4D),
        orb = Color(0xFFC6D5B8), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF6B8261).copy(alpha = 0.3f),
        footer = Color(0xFF83907C).copy(alpha = 0.9f), cardHint = Color(0xFF83907C)
    ),
    // Day 7 · Blush
    CalmPalette(
        bgTop = Color(0xFFF6EFEC), bgBottom = Color(0xFFFAF5F2),
        text = Color(0xFF4E413C), dim = Color(0xFF97867F), accent = Color(0xFF9C7C72),
        cardBg = Color(0xFFEAE0DB), cardBorder = Color(0xFF9C7C72).copy(alpha = 0.25f),
        chipBg = Color(0xFF9C7C72).copy(alpha = 0.16f), chipText = Color(0xFF7E5F56),
        orb = Color(0xFFDFC9C0), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF9C7C72).copy(alpha = 0.3f),
        footer = Color(0xFF97867F).copy(alpha = 0.9f), cardHint = Color(0xFF97867F)
    )
)

private val NightThemes = listOf(
    // Night 1 · Deep Navy
    CalmPalette(
        bgTop = Color(0xFF0D1726), bgBottom = Color(0xFF13233C),
        text = Color(0xFFE8EEF9), dim = Color(0xFF9FAFC8), accent = Color(0xFFAFC4F5),
        cardBg = Color(0xFF182A45), cardBorder = Color(0xFFAFC4F5).copy(alpha = 0.12f),
        chipBg = Color(0xFFAFC4F5).copy(alpha = 0.16f), chipText = Color(0xFFAFC4F5),
        orb = Color(0xFFAFC4F5), orbInnerAlpha = 0.48f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFAFC4F5).copy(alpha = 0.25f),
        footer = Color(0xFF9FAFC8).copy(alpha = 0.9f), cardHint = Color(0xFF9FAFC8)
    ),
    // Night 2 · Slate
    CalmPalette(
        bgTop = Color(0xFF26364D), bgBottom = Color(0xFF2E4059),
        text = Color(0xFFF0F5FC), dim = Color(0xFFB3C1D8), accent = Color(0xFFBDD0F7),
        cardBg = Color(0xFF3A4E6E), cardBorder = Color(0xFFBDD0F7).copy(alpha = 0.18f),
        chipBg = Color(0xFFBDD0F7).copy(alpha = 0.2f), chipText = Color(0xFFD3E0FA),
        orb = Color(0xFFBDD0F7), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFBDD0F7).copy(alpha = 0.3f),
        footer = Color(0xFFB3C1D8).copy(alpha = 0.9f), cardHint = Color(0xFFB3C1D8)
    ),
    // Night 3 · Evening Sage
    CalmPalette(
        bgTop = Color(0xFF3B473E), bgBottom = Color(0xFF46544A),
        text = Color(0xFFF0F4EC), dim = Color(0xFFC0CCBA), accent = Color(0xFFCFDFC4),
        cardBg = Color(0xFF536354), cardBorder = Color(0xFFCFDFC4).copy(alpha = 0.2f),
        chipBg = Color(0xFFCFDFC4).copy(alpha = 0.22f), chipText = Color(0xFFDCE8D2),
        orb = Color(0xFFC6D8B9), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFCFDFC4).copy(alpha = 0.3f),
        footer = Color(0xFFC0CCBA).copy(alpha = 0.9f), cardHint = Color(0xFFC0CCBA)
    ),
    // Night 4 · Deep Forest (your +2 baseline)
    CalmPalette(
        bgTop = Color(0xFF1A4028), bgBottom = Color(0xFF225130),
        text = Color(0xFFF7FBF6), dim = Color(0xFFA9C4AC), accent = Color(0xFFD6EAC3),
        cardBg = Color(0xFF285E3A), cardBorder = Color(0xFFE0F0D2).copy(alpha = 0.18f),
        chipBg = Color(0xFFE0F0D2).copy(alpha = 0.16f), chipText = Color(0xFFD6EAC3),
        orb = Color(0xFFBCE2BF), orbInnerAlpha = 0.45f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFE0F0D2).copy(alpha = 0.28f),
        footer = Color(0xFFA9C4AC).copy(alpha = 0.9f), cardHint = Color(0xFFA9C4AC)
    ),
    // Night 5 · Midnight Plum (your +2 baseline)
    CalmPalette(
        bgTop = Color(0xFF2D1F4D), bgBottom = Color(0xFF3B2A61),
        text = Color(0xFFFCFAFE), dim = Color(0xFFC0B4DC), accent = Color(0xFFD9CAF5),
        cardBg = Color(0xFF443376), cardBorder = Color(0xFFE6DBF8).copy(alpha = 0.18f),
        chipBg = Color(0xFFE6DBF8).copy(alpha = 0.18f), chipText = Color(0xFFE4DAF9),
        orb = Color(0xFFD8CAF5), orbInnerAlpha = 0.45f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFE6DBF8).copy(alpha = 0.28f),
        footer = Color(0xFFC0B4DC).copy(alpha = 0.9f), cardHint = Color(0xFFC0B4DC)
    ),
    // Night 6 · Ember (your +2 baseline)
    CalmPalette(
        bgTop = Color(0xFF3E231D), bgBottom = Color(0xFF4F3024),
        text = Color(0xFFFAF4EF), dim = Color(0xFFCEAC99), accent = Color(0xFFF2BC9C),
        cardBg = Color(0xFF5E3C2C), cardBorder = Color(0xFFF5C8AE).copy(alpha = 0.18f),
        chipBg = Color(0xFFF5C8AE).copy(alpha = 0.16f), chipText = Color(0xFFF6CFB5),
        orb = Color(0xFFF0BD9D), orbInnerAlpha = 0.42f, orbOuterAlpha = 0.07f,
        ring = Color(0xFFF5C8AE).copy(alpha = 0.26f),
        footer = Color(0xFFCEAC99).copy(alpha = 0.9f), cardHint = Color(0xFFCEAC99)
    )
)

private val LocalPalette = staticCompositionLocalOf { NightThemes[0] }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences("calm_now", Context.MODE_PRIVATE)
        setContent {
            val systemDark = isSystemInDarkTheme()
            // mode: -1 follow system (first launch), 0 day, 1 night
            var mode by remember { mutableIntStateOf(prefs.getInt("mode", -1)) }
            var dayIx by remember {
                mutableIntStateOf(prefs.getInt("day_ix", 0).coerceIn(0, DayThemes.lastIndex))
            }
            var nightIx by remember {
                mutableIntStateOf(prefs.getInt("night_ix", 0).coerceIn(0, NightThemes.lastIndex))
            }
            val isNight = when (mode) {
                0 -> false
                1 -> true
                else -> systemDark
            }
            val palette = if (isNight) NightThemes[nightIx] else DayThemes[dayIx]
            val scheme = if (isNight) {
                darkColorScheme(primary = palette.accent, background = palette.bgTop, onBackground = palette.text)
            } else {
                lightColorScheme(primary = palette.accent, background = palette.bgTop, onBackground = palette.text)
            }
            CompositionLocalProvider(LocalPalette provides palette) {
                MaterialTheme(colorScheme = scheme) {
                    CalmScreen(
                        isNight = isNight,
                        onToggleDayNight = {
                            val m = if (isNight) 0 else 1
                            mode = m
                            prefs.edit().putInt("mode", m).apply()
                        },
                        onNextPalette = {
                            if (isNight) {
                                nightIx = (nightIx + 1) % NightThemes.size
                                prefs.edit().putInt("night_ix", nightIx).apply()
                            } else {
                                dayIx = (dayIx + 1) % DayThemes.size
                                prefs.edit().putInt("day_ix", dayIx).apply()
                            }
                        }
                    )
                }
            }
        }
    }
}

// ---------- Screen ----------

@Composable
fun CalmScreen(isNight: Boolean, onToggleDayNight: () -> Unit, onNextPalette: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            Text(
                text = "You're okay.",
                fontSize = 32.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "What you're feeling is intense, but it is not dangerous — and it will pass. Breathe with the circle.",
                fontSize = 16.sp,
                lineHeight = 24.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(28.dp))
            BreathingCircle()
            Spacer(Modifier.height(10.dp))
            Text(
                text = "A longer breath out tells your body the danger has passed.",
                fontSize = 14.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(32.dp))
            SectionCard(title = "Ground yourself · 5-4-3-2-1") {
                GroundingRow("5", "things you can see around you")
                GroundingRow("4", "things you can touch or feel")
                GroundingRow("3", "sounds you can hear")
                GroundingRow("2", "things you can smell")
                GroundingRow("1", "thing you can taste")
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Go slowly. Name them out loud if you can.",
                    fontSize = 14.sp,
                    color = c.cardHint
                )
            }

            Spacer(Modifier.height(16.dp))
            SectionCard(title = "Remember") {
                ReassuranceLine("Panic usually peaks within a few minutes, then fades. It always passes.")
                ReassuranceLine("This is your body's alarm going off by mistake. It feels awful, but it isn't harming you.")
                ReassuranceLine("Don't fight the wave. Let it rise, crest, and fall on its own.")
                ReassuranceLine("Cold resets the body: splash water on your face, or press a cool, wet cloth to the back of your neck or the base of your spine.")
            }

            Spacer(Modifier.height(28.dp))
            Text(
                text = "Panic attacks are common and very treatable. If they keep happening, a doctor or therapist can genuinely help.\n\nChest pain that is new or different for you? It's always okay to seek medical care — dial 112 anywhere in the EU. For free emotional support, call or text 988 in the US, or call 116 123 in many EU countries.",
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = c.footer,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))
        }

        // Top-right controls: palette stepper + day/night toggle
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .systemBarsPadding()
                .padding(top = 12.dp, end = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // steps through your six days or six nights, depending on the side you're on
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(c.cardBg)
                    .border(1.dp, c.ring, CircleShape)
                    .clickable(onClick = onNextPalette),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎨", fontSize = 22.sp)
            }
            // day/night toggle — remembers your last-used day and night
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(c.cardBg)
                    .border(1.dp, c.ring, CircleShape)
                    .clickable(onClick = onToggleDayNight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = if (isNight) "☀️" else "🌙", fontSize = 24.sp)
            }
        }
    }
}

// ---------- Breathing guide (4 in · 4 hold · 6 out) ----------

private enum class BreathPhase(val label: String, val seconds: Int, val targetScale: Float) {
    Inhale("Breathe in", 4, 1f),
    Hold("Hold", 4, 1f),
    Exhale("Breathe out", 6, 0.55f)
}

@Composable
private fun BreathingCircle(modifier: Modifier = Modifier) {
    val c = LocalPalette.current
    var phase by remember { mutableStateOf(BreathPhase.Inhale) }
    var count by remember { mutableIntStateOf(BreathPhase.Inhale.seconds) }
    val scale = remember { Animatable(BreathPhase.Exhale.targetScale) }

    LaunchedEffect(Unit) {
        while (isActive) {
            for (p in BreathPhase.entries) {
                phase = p
                count = p.seconds
                coroutineScope {
                    launch {
                        scale.animateTo(
                            targetValue = p.targetScale,
                            animationSpec = tween(
                                durationMillis = p.seconds * 1000,
                                easing = FastOutSlowInEasing
                            )
                        )
                    }
                    launch {
                        repeat(p.seconds) { i ->
                            count = p.seconds - i
                            delay(1000L)
                        }
                    }
                }
            }
        }
    }

    Box(modifier = modifier.size(280.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .matchParentSize()
                .border(1.5.dp, c.ring, CircleShape)
        )
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .background(
                    Brush.radialGradient(
                        listOf(
                            c.orb.copy(alpha = c.orbInnerAlpha),
                            c.orb.copy(alpha = c.orbOuterAlpha)
                        )
                    ),
                    CircleShape
                )
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = phase.label,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
                color = c.text
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = count.toString(),
                fontSize = 44.sp,
                fontWeight = FontWeight.Light,
                color = c.text.copy(alpha = 0.9f)
            )
        }
    }
}

// ---------- Small building blocks ----------

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(c.cardBg, RoundedCornerShape(20.dp))
            .border(1.dp, c.cardBorder, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.accent
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun GroundingRow(number: String, text: String) {
    val c = LocalPalette.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(c.chipBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = c.chipText,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 16.sp,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun ReassuranceLine(text: String) {
    val c = LocalPalette.current
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Text(text = "·", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 15.sp,
            lineHeight = 22.sp
        )
    }
}
