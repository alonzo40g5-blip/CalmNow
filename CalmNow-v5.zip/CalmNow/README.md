# Calm Now

A single-screen Android app for riding out a panic attack. It opens straight to a guided breathing circle (4s in, 4s hold, 6s out), followed by the 5-4-3-2-1 grounding exercise and a few gentle reminders. No buttons to hunt for, no setup — just open it and breathe.

Built with Kotlin and Jetpack Compose. Twelve themes — six days (Sky, Warm Cream, Off-White, Mist, Soft Sage, Blush) and six nights (Deep Navy, Slate, Evening Sage, Deep Forest, Midnight Plum, Ember). The moon/sun button toggles day and night; the palette button steps through the six themes of the current side. Both are remembered; only the very first launch follows the device's light/dark setting.

## Run it

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Open Android Studio → **File → Open** → select this `CalmNow` folder.
3. Let Gradle sync (first sync downloads dependencies, so you'll need internet). If Android Studio mentions a missing Gradle wrapper, accept its offer to fix it — this project ships without the wrapper binary.
4. Connect an Android phone with USB debugging enabled (or start an emulator) and press **Run ▶**.

To put it on a phone permanently without a cable each time: **Build → Generate Signed App Bundle / APK → APK**, then copy the APK to the phone and install it.

## Or: build it on GitHub — the zip-only way

The repo needs exactly **two things at its root**, nothing else:

1. `.github/workflows/build.yml` — you already have this. If unsure it's the right version, open it, hit the pencil, and paste the copy included in this zip at the same path (it must contain an "unzip if needed" step).
2. `CalmNow.zip` — this zip, uploaded **as-is**, no extracting: repo main page → **Add file → Upload files** → pick the zip → Commit.

That commit triggers the build. The workflow unzips the project by itself, compiles it, and publishes the result. When the run is green: **Actions** tab → the run → **Artifacts** → download **CalmNow-debug-apk** → inside is `CalmNow.apk`. Copy it to the phone and tap to install (allow installs from unknown sources when asked).

To ship any future change: just upload a new `CalmNow.zip` over the old one. First build takes ~5–8 minutes; later ones are faster.

## Customize

Everything lives in one file: `app/src/main/java/com/example/calmnow/MainActivity.kt`

- **Colors** — the `DayThemes` and `NightThemes` lists at the top of the file, six palettes each, in your approved order.
- **Breathing rhythm** — the `BreathPhase` enum (labels, seconds, circle size). Swap in box breathing by making it 4-4-4 plus a second hold.
- **All text** — the strings inside `CalmScreen()`.
- **App name** — `app/src/main/res/values/strings.xml`.

## A note on the content

The reassurance lines follow standard psychoeducation used in CBT for panic: the attack is time-limited, not dangerous, and fighting it tends to prolong it. The footer deliberately keeps two doors open — professional help for recurring attacks, and medical care for symptoms that are new or different.
