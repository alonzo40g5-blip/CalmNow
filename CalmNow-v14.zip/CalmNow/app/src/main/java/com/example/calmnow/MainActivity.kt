package com.example.calmnow

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.animation.core.tween as animTween
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// ---------- Your twelve palettes, exactly as approved ----------

@Immutable
data class CalmPalette(
    val bgTop: Color,
    val bgBottom: Color,
    val text: Color,
    val dim: Color,
    val accent: Color,
    val cardBg: Color,
    val cardBorder: Color,
    val chipBg: Color,
    val chipText: Color,
    val orb: Color,
    val orbInnerAlpha: Float,
    val orbOuterAlpha: Float,
    val ring: Color,
    val footer: Color,
    val cardHint: Color
)

private val ThemeNames = listOf(
    "Sky", "Cream", "Off-White", "Mist", "Sage", "Blush",
    "Navy", "Slate", "Ev. Sage", "Forest", "Plum", "Ember"
)

private val AllThemes = listOf(
    // 0 · Day · Sky
    CalmPalette(
        bgTop = Color(0xFFE9F2FA), bgBottom = Color(0xFFF4F7F0),
        text = Color(0xFF2E4257), dim = Color(0xFF74879D), accent = Color(0xFF4E79B0),
        cardBg = Color(0xFFE2EDF8), cardBorder = Color(0xFF4E79B0).copy(alpha = 0.15f),
        chipBg = Color(0xFF7BA483).copy(alpha = 0.22f), chipText = Color(0xFF55795F),
        orb = Color(0xFF76A0D4), orbInnerAlpha = 0.48f, orbOuterAlpha = 0.08f,
        ring = Color(0xFF4E79B0).copy(alpha = 0.28f),
        footer = Color(0xFF74879D).copy(alpha = 0.9f), cardHint = Color(0xFF74879D)
    ),
    // 1 · Day · Warm Cream
    CalmPalette(
        bgTop = Color(0xFFF7F2E8), bgBottom = Color(0xFFFBF7EF),
        text = Color(0xFF4A4238), dim = Color(0xFF93887A), accent = Color(0xFF7C8F6A),
        cardBg = Color(0xFFF4EEE1), cardBorder = Color(0xFF7C8F6A).copy(alpha = 0.25f),
        chipBg = Color(0xFF9AAB89).copy(alpha = 0.25f), chipText = Color(0xFF5C6E4C),
        orb = Color(0xFFA9BC94), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFF7C8F6A).copy(alpha = 0.35f),
        footer = Color(0xFF93887A).copy(alpha = 0.9f), cardHint = Color(0xFF93887A)
    ),
    // 2 · Day · Off-White
    CalmPalette(
        bgTop = Color(0xFFFBFAF7), bgBottom = Color(0xFFF5F2EA),
        text = Color(0xFF4C4A43), dim = Color(0xFF918D80), accent = Color(0xFF7E7A6C),
        cardBg = Color(0xFFEFEBDF), cardBorder = Color(0xFF7E7A6C).copy(alpha = 0.28f),
        chipBg = Color(0xFF7E7A6C).copy(alpha = 0.14f), chipText = Color(0xFF6E6A5C),
        orb = Color(0xFFD9D3C0), orbInnerAlpha = 0.55f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF7E7A6C).copy(alpha = 0.3f),
        footer = Color(0xFF918D80).copy(alpha = 0.9f), cardHint = Color(0xFF918D80)
    ),
    // 3 · Day · Mist
    CalmPalette(
        bgTop = Color(0xFFEDF1F4), bgBottom = Color(0xFFF5F7F9),
        text = Color(0xFF38434E), dim = Color(0xFF7E8B98), accent = Color(0xFF5A7186),
        cardBg = Color(0xFFDBE2E8), cardBorder = Color(0xFF5A7186).copy(alpha = 0.25f),
        chipBg = Color(0xFF5A7186).copy(alpha = 0.15f), chipText = Color(0xFF4C6478),
        orb = Color(0xFFC9D2DA), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF5A7186).copy(alpha = 0.3f),
        footer = Color(0xFF7E8B98).copy(alpha = 0.9f), cardHint = Color(0xFF7E8B98)
    ),
    // 4 · Day · Soft Sage
    CalmPalette(
        bgTop = Color(0xFFEDF2E9), bgBottom = Color(0xFFF5F8F2),
        text = Color(0xFF3F4A3C), dim = Color(0xFF83907C), accent = Color(0xFF6B8261),
        cardBg = Color(0xFFDBE5D2), cardBorder = Color(0xFF6B8261).copy(alpha = 0.25f),
        chipBg = Color(0xFF6B8261).copy(alpha = 0.16f), chipText = Color(0xFF566B4D),
        orb = Color(0xFFC6D5B8), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF6B8261).copy(alpha = 0.3f),
        footer = Color(0xFF83907C).copy(alpha = 0.9f), cardHint = Color(0xFF83907C)
    ),
    // 5 · Day · Blush
    CalmPalette(
        bgTop = Color(0xFFF6EFEC), bgBottom = Color(0xFFFAF5F2),
        text = Color(0xFF4E413C), dim = Color(0xFF97867F), accent = Color(0xFF9C7C72),
        cardBg = Color(0xFFEAE0DB), cardBorder = Color(0xFF9C7C72).copy(alpha = 0.25f),
        chipBg = Color(0xFF9C7C72).copy(alpha = 0.16f), chipText = Color(0xFF7E5F56),
        orb = Color(0xFFDFC9C0), orbInnerAlpha = 0.6f, orbOuterAlpha = 0.1f,
        ring = Color(0xFF9C7C72).copy(alpha = 0.3f),
        footer = Color(0xFF97867F).copy(alpha = 0.9f), cardHint = Color(0xFF97867F)
    ),
    // 6 · Night · Deep Navy
    CalmPalette(
        bgTop = Color(0xFF0D1726), bgBottom = Color(0xFF13233C),
        text = Color(0xFFE8EEF9), dim = Color(0xFF9FAFC8), accent = Color(0xFFAFC4F5),
        cardBg = Color(0xFF182A45), cardBorder = Color(0xFFAFC4F5).copy(alpha = 0.12f),
        chipBg = Color(0xFFAFC4F5).copy(alpha = 0.16f), chipText = Color(0xFFAFC4F5),
        orb = Color(0xFFAFC4F5), orbInnerAlpha = 0.48f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFAFC4F5).copy(alpha = 0.25f),
        footer = Color(0xFF9FAFC8).copy(alpha = 0.9f), cardHint = Color(0xFF9FAFC8)
    ),
    // 7 · Night · Slate
    CalmPalette(
        bgTop = Color(0xFF26364D), bgBottom = Color(0xFF2E4059),
        text = Color(0xFFF0F5FC), dim = Color(0xFFB3C1D8), accent = Color(0xFFBDD0F7),
        cardBg = Color(0xFF3A4E6E), cardBorder = Color(0xFFBDD0F7).copy(alpha = 0.18f),
        chipBg = Color(0xFFBDD0F7).copy(alpha = 0.2f), chipText = Color(0xFFD3E0FA),
        orb = Color(0xFFBDD0F7), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFBDD0F7).copy(alpha = 0.3f),
        footer = Color(0xFFB3C1D8).copy(alpha = 0.9f), cardHint = Color(0xFFB3C1D8)
    ),
    // 8 · Night · Evening Sage
    CalmPalette(
        bgTop = Color(0xFF3B473E), bgBottom = Color(0xFF46544A),
        text = Color(0xFFF0F4EC), dim = Color(0xFFC0CCBA), accent = Color(0xFFCFDFC4),
        cardBg = Color(0xFF536354), cardBorder = Color(0xFFCFDFC4).copy(alpha = 0.2f),
        chipBg = Color(0xFFCFDFC4).copy(alpha = 0.22f), chipText = Color(0xFFDCE8D2),
        orb = Color(0xFFC6D8B9), orbInnerAlpha = 0.5f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFCFDFC4).copy(alpha = 0.3f),
        footer = Color(0xFFC0CCBA).copy(alpha = 0.9f), cardHint = Color(0xFFC0CCBA)
    ),
    // 9 · Night · Deep Forest (your +2 baseline)
    CalmPalette(
        bgTop = Color(0xFF1A4028), bgBottom = Color(0xFF225130),
        text = Color(0xFFF7FBF6), dim = Color(0xFFA9C4AC), accent = Color(0xFFD6EAC3),
        cardBg = Color(0xFF285E3A), cardBorder = Color(0xFFE0F0D2).copy(alpha = 0.18f),
        chipBg = Color(0xFFE0F0D2).copy(alpha = 0.16f), chipText = Color(0xFFD6EAC3),
        orb = Color(0xFFBCE2BF), orbInnerAlpha = 0.45f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFE0F0D2).copy(alpha = 0.28f),
        footer = Color(0xFFA9C4AC).copy(alpha = 0.9f), cardHint = Color(0xFFA9C4AC)
    ),
    // 10 · Night · Midnight Plum (your +2 baseline)
    CalmPalette(
        bgTop = Color(0xFF2D1F4D), bgBottom = Color(0xFF3B2A61),
        text = Color(0xFFFCFAFE), dim = Color(0xFFC0B4DC), accent = Color(0xFFD9CAF5),
        cardBg = Color(0xFF443376), cardBorder = Color(0xFFE6DBF8).copy(alpha = 0.18f),
        chipBg = Color(0xFFE6DBF8).copy(alpha = 0.18f), chipText = Color(0xFFE4DAF9),
        orb = Color(0xFFD8CAF5), orbInnerAlpha = 0.45f, orbOuterAlpha = 0.08f,
        ring = Color(0xFFE6DBF8).copy(alpha = 0.28f),
        footer = Color(0xFFC0B4DC).copy(alpha = 0.9f), cardHint = Color(0xFFC0B4DC)
    ),
    // 11 · Night · Ember (your +2 baseline)
    CalmPalette(
        bgTop = Color(0xFF3E231D), bgBottom = Color(0xFF4F3024),
        text = Color(0xFFFAF4EF), dim = Color(0xFFCEAC99), accent = Color(0xFFF2BC9C),
        cardBg = Color(0xFF5E3C2C), cardBorder = Color(0xFFF5C8AE).copy(alpha = 0.18f),
        chipBg = Color(0xFFF5C8AE).copy(alpha = 0.16f), chipText = Color(0xFFF6CFB5),
        orb = Color(0xFFF0BD9D), orbInnerAlpha = 0.42f, orbOuterAlpha = 0.07f,
        ring = Color(0xFFF5C8AE).copy(alpha = 0.26f),
        footer = Color(0xFFCEAC99).copy(alpha = 0.9f), cardHint = Color(0xFFCEAC99)
    )
)

// ---------- Color math: lightness shifts + contrast guard ----------

private fun Color.toHsl(): FloatArray {
    val r = red; val g = green; val b = blue
    val max = maxOf(r, g, b); val min = minOf(r, g, b)
    var h = 0f; var s = 0f; val l = (max + min) / 2f
    if (max != min) {
        val d = max - min
        s = if (l > 0.5f) d / (2f - max - min) else d / (max + min)
        h = when (max) {
            r -> (g - b) / d + (if (g < b) 6f else 0f)
            g -> (b - r) / d + 2f
            else -> (r - g) / d + 4f
        } / 6f
    }
    return floatArrayOf(h, s, l)
}

private fun hslColor(h: Float, s: Float, l: Float): Color {
    if (s == 0f) return Color(l, l, l)
    val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
    val p = 2f * l - q
    fun channel(t0: Float): Float {
        var t = t0
        if (t < 0f) t += 1f
        if (t > 1f) t -= 1f
        return when {
            t < 1f / 6f -> p + (q - p) * 6f * t
            t < 1f / 2f -> q
            t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
            else -> p
        }
    }
    return Color(channel(h + 1f / 3f), channel(h), channel(h - 1f / 3f))
}

private fun Color.shiftLightness(deltaPercent: Float): Color {
    val hsl = toHsl()
    val l = (hsl[2] + deltaPercent / 100f).coerceIn(0f, 1f)
    return hslColor(hsl[0], hsl[1], l)
}

private fun contrastRatio(a: Color, b: Color): Float {
    val la = a.luminance(); val lb = b.luminance()
    return (maxOf(la, lb) + 0.05f) / (minOf(la, lb) + 0.05f)
}

// nudge fg away from bg until readable — no mix can break
private fun ensureContrast(start: Color, bg: Color, minRatio: Float): Color {
    var fg = start
    var tries = 0
    val dir = if (bg.luminance() > 0.45f) -4f else 4f
    while (contrastRatio(fg, bg) < minRatio && tries < 14) {
        fg = fg.shiftLightness(dir)
        tries++
    }
    return fg
}

// ---------- A mix: four picks + depth, composed into a full palette ----------

private data class Mix(val bg: Int, val card: Int, val orb: Int, val acc: Int, val depth: Int)

private fun defaultMix(nightSide: Boolean) =
    if (nightSide) Mix(6, 6, 6, 6, 0) else Mix(0, 0, 0, 0, 0)

private fun Mix.isMatchedTheme(): Boolean = bg == card && card == orb && orb == acc

private fun composeMix(mix: Mix): CalmPalette {
    val d = mix.depth.toFloat()
    val bgD = minOf(d, 0f)      // background may darken, NEVER lighten
    val inkD = minOf(d, 0f) / 2f
    val tBg = AllThemes[mix.bg]
    val tCard = AllThemes[mix.card]
    val tOrb = AllThemes[mix.orb]
    val tAcc = AllThemes[mix.acc]

    val bgTop = tBg.bgTop.shiftLightness(bgD)
    val bgBottom = tBg.bgBottom.shiftLightness(bgD)
    val cardBg = tCard.cardBg.shiftLightness(d)

    return CalmPalette(
        bgTop = bgTop,
        bgBottom = bgBottom,
        text = ensureContrast(tBg.text.shiftLightness(inkD), bgTop, 4.5f),
        dim = ensureContrast(tBg.dim.shiftLightness(inkD), bgTop, 3f),
        accent = ensureContrast(tAcc.accent.shiftLightness(inkD), cardBg, 3.4f),
        cardBg = cardBg,
        cardBorder = tCard.cardBorder.copy(alpha = tCard.cardBorder.alpha)
            .shiftLightness(d).copy(alpha = tCard.cardBorder.alpha),
        chipBg = tAcc.chipBg.shiftLightness(d).copy(alpha = tAcc.chipBg.alpha),
        chipText = ensureContrast(tAcc.chipText.shiftLightness(inkD), cardBg, 3.4f),
        orb = tOrb.orb.shiftLightness(d),
        orbInnerAlpha = tOrb.orbInnerAlpha,
        orbOuterAlpha = tOrb.orbOuterAlpha,
        ring = tOrb.ring.shiftLightness(d).copy(alpha = tOrb.ring.alpha),
        footer = ensureContrast(tBg.footer.copy(alpha = 1f).shiftLightness(inkD), bgTop, 3f).copy(alpha = 0.9f),
        cardHint = ensureContrast(tBg.cardHint.shiftLightness(inkD), cardBg, 3f)
    )
}

private val LocalPalette = staticCompositionLocalOf { AllThemes[6] }

// ---------- Activity ----------

private fun SharedPreferences.loadMix(nightSide: Boolean): Mix {
    val p = if (nightSide) "n_" else "d_"
    val def = defaultMix(nightSide)
    return Mix(
        bg = getInt(p + "bg", def.bg).coerceIn(0, AllThemes.lastIndex),
        card = getInt(p + "card", def.card).coerceIn(0, AllThemes.lastIndex),
        orb = getInt(p + "orb", def.orb).coerceIn(0, AllThemes.lastIndex),
        acc = getInt(p + "acc", def.acc).coerceIn(0, AllThemes.lastIndex),
        depth = getInt(p + "dep", 0).coerceIn(-8, 8)
    )
}

private fun SharedPreferences.saveMix(nightSide: Boolean, mix: Mix) {
    val p = if (nightSide) "n_" else "d_"
    edit().putInt(p + "bg", mix.bg).putInt(p + "card", mix.card)
        .putInt(p + "orb", mix.orb).putInt(p + "acc", mix.acc)
        .putInt(p + "dep", mix.depth).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences("calm_now", Context.MODE_PRIVATE)
        setContent {
            val systemDark = isSystemInDarkTheme()
            var mode by remember { mutableIntStateOf(prefs.getInt("mode", -1)) } // -1 system, 0 day, 1 night
            var dayMix by remember { mutableStateOf(prefs.loadMix(false)) }
            var nightMix by remember { mutableStateOf(prefs.loadMix(true)) }
            var showPlay by remember { mutableStateOf(false) }
            var showBook by remember { mutableStateOf(false) }

            val isNight = when (mode) { 0 -> false; 1 -> true; else -> systemDark }
            val mix = if (isNight) nightMix else dayMix
            val palette = composeMix(mix)
            val scheme = if (isNight) {
                darkColorScheme(primary = palette.accent, background = palette.bgTop, onBackground = palette.text)
            } else {
                lightColorScheme(primary = palette.accent, background = palette.bgTop, onBackground = palette.text)
            }

            fun updateMix(new: Mix) {
                if (isNight) { nightMix = new; prefs.saveMix(true, new) }
                else { dayMix = new; prefs.saveMix(false, new) }
            }

            BackHandler(enabled = showPlay || showBook) { showPlay = false; showBook = false }

            CompositionLocalProvider(LocalPalette provides palette) {
                MaterialTheme(colorScheme = scheme) {
                    if (showBook) {
                        BookScreen(onBack = { showBook = false })
                    } else if (showPlay) {
                        PlayScreen(
                            mix = mix,
                            onBack = { showPlay = false },
                            onReset = { updateMix(defaultMix(isNight)) },
                            onMixChange = { updateMix(it) }
                        )
                    } else {
                        CalmScreen(
                            isNight = isNight,
                            onToggleDayNight = {
                                val m = if (isNight) 0 else 1
                                mode = m
                                prefs.edit().putInt("mode", m).apply()
                            },
                            onOpenPlay = { showPlay = true },
                            onOpenBook = { showBook = true }
                        )
                    }
                }
            }
        }
    }
}

// ---------- Page 1: the breathing screen ----------

@Composable
fun CalmScreen(isNight: Boolean, onToggleDayNight: () -> Unit, onOpenPlay: () -> Unit, onOpenBook: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            Text(
                text = "You're okay.",
                fontSize = 32.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "What you're feeling is intense, but it is not dangerous — and it will pass. Breathe with the circle.",
                fontSize = 16.sp,
                lineHeight = 24.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(28.dp))
            BreathingCircle()
            Spacer(Modifier.height(10.dp))
            Text(
                text = "A longer breath out tells your body the danger has passed.",
                fontSize = 14.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(32.dp))
            SectionCard(title = "Ground yourself · 5-4-3-2-1") {
                GroundingRow("5", "things you can see around you")
                GroundingRow("4", "things you can touch or feel")
                GroundingRow("3", "sounds you can hear")
                GroundingRow("2", "things you can smell")
                GroundingRow("1", "thing you can taste")
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Go slowly. Name them out loud if you can.",
                    fontSize = 14.sp,
                    color = c.cardHint
                )
            }

            Spacer(Modifier.height(16.dp))
            SectionCard(title = "When the waves keep coming") {
                ReassuranceLine("Panic can roll in waves — one eases, then another builds. This is common and it is not a sign anything is wrong with you.")
                ReassuranceLine("Each wave leaves your body primed, so a racing heart or fast breathing can trip the next one. Slowing the breath breaks that loop.")
                ReassuranceLine("A fast heartbeat during panic is adrenaline doing its job, not your heart failing — especially reassuring if a doctor has checked you and found it sound.")
                ReassuranceLine("If medication that used to help is starting to slip, that is a signal to see your prescriber — not a failing on your part. There are usually more options.")
                ReassuranceLine("The exhaustion afterward is an adrenaline hangover. Rest, water, and going easy on yourself are the cure; it passes.")
            }

            Spacer(Modifier.height(16.dp))
            SectionCard(title = "Remember") {
                ReassuranceLine("Panic usually peaks within a few minutes, then fades. It always passes.")
                ReassuranceLine("This is your body's alarm going off by mistake. It feels awful, but it isn't harming you.")
                ReassuranceLine("Don't fight the wave. Let it rise, crest, and fall on its own.")
                ReassuranceLine("Cold shocks the system and can break the wave: press an iced bottle to the back of your neck, or to your lower spine — many find that hits harder. Splashing cold water on your face works too. Keep it moving so it doesn't hurt the skin.")
            }

            Spacer(Modifier.height(28.dp))
            Text(
                text = "Panic attacks are common and very treatable. If they keep happening, a doctor or therapist can genuinely help.\n\nChest pain that is new or different for you? It's always okay to seek medical care — dial 112 anywhere in the EU. For free emotional support, call or text 988 in the US, or call 116 123 in many EU countries.",
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = c.footer,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))
        }

        // Top-right controls: 🎨 opens Make it yours · 🌙/☀️ toggles day and night
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .systemBarsPadding()
                .padding(top = 12.dp, end = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(c.cardBg)
                    .border(1.dp, c.ring, CircleShape)
                    .clickable(onClick = onOpenBook),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "📖", fontSize = 22.sp)
            }
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(c.cardBg)
                    .border(1.dp, c.ring, CircleShape)
                    .clickable(onClick = onOpenPlay),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎨", fontSize = 22.sp)
            }
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(c.cardBg)
                    .border(1.dp, c.ring, CircleShape)
                    .clickable(onClick = onToggleDayNight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = if (isNight) "☀️" else "🌙", fontSize = 24.sp)
            }
        }
    }
}

// ---------- Page 2: Make it yours ----------

@Composable
private fun PlayScreen(mix: Mix, onBack: () -> Unit, onReset: () -> Unit, onMixChange: (Mix) -> Unit) {
    val c = LocalPalette.current
    var mixOpen by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            // Back + Reset, both big and unmistakable
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Pill(text = "← Back to breathing", onClick = onBack)
                Pill(text = "↩ Reset", onClick = onReset)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                text = "Make it yours",
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.text,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Playing with color genuinely calms the brain: gentle, absorbing choosing creates flow and enjoyment, and making your own choices restores a sense of control that softens stress. Every color here was chosen for calm — pick freely, every combination is a good one. And if anything looks odd, one tap on Reset brings it all back. You cannot break this.",
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = c.dim,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(14.dp))
            PreviewPanel(mix)

            Spacer(Modifier.height(18.dp))
            Text(
                text = "CHOOSE YOUR THEME",
                fontSize = 11.sp,
                letterSpacing = 2.sp,
                color = c.dim
            )
            Spacer(Modifier.height(8.dp))
            ThemeNames.indices.chunked(3).forEach { rowIdx ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowIdx.forEach { i ->
                        ThemeTile(
                            index = i,
                            selected = mix.isMatchedTheme() && mix.bg == i,
                            modifier = Modifier.weight(1f)
                        ) { onMixChange(Mix(i, i, i, i, mix.depth)) }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            Spacer(Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, c.ring, RoundedCornerShape(12.dp))
                    .clickable { mixOpen = !mixOpen }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (mixOpen) "MIX PIECES · OPTIONAL ▲" else "MIX PIECES · OPTIONAL ▼",
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    color = c.dim
                )
            }

            if (mixOpen) {
                MixSection("BACKGROUND", mix.bg) { onMixChange(mix.copy(bg = it)) }
                MixSection("CARDS", mix.card) { onMixChange(mix.copy(card = it)) }
                MixSection("BREATHING CIRCLE", mix.orb) { onMixChange(mix.copy(orb = it)) }
                MixSection("ACCENT · TITLES & NUMBERS", mix.acc) { onMixChange(mix.copy(acc = it)) }

                Spacer(Modifier.height(14.dp))
                Text(
                    text = "WHOLE THEME · LIGHTER CARDS ← → DARKER ALL (BG NEVER LIGHTENS)",
                    fontSize = 9.sp,
                    letterSpacing = 1.5.sp,
                    color = c.dim
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(8 to "+2", 4 to "+1", 0 to "yours", -4 to "−1", -8 to "−2").forEach { (d, label) ->
                        DepthChip(
                            mix = mix, depth = d, label = label,
                            selected = mix.depth == d
                        ) { onMixChange(mix.copy(depth = d)) }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                text = "Made by you, for you — and that ownership is part of what makes it work.",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = c.footer,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(c.cardBg)
            .border(1.5.dp, c.ring, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Text(text = text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.text)
    }
}

@Composable
private fun PreviewPanel(mix: Mix) {
    val c = LocalPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, c.cardBorder, RoundedCornerShape(16.dp))
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("You're okay.", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.text)
        Spacer(Modifier.height(6.dp))
        BreathingCircle(circleSize = 140.dp, compact = true)
        Spacer(Modifier.height(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(c.cardBg)
                .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text("Ground yourself · 5-4-3-2-1", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c.accent)
            Spacer(Modifier.height(4.dp))
            MiniRow("5", "things you can see around you")
            MiniRow("4", "things you can touch or feel")
        }
        Spacer(Modifier.height(6.dp))
        val name = if (mix.isMatchedTheme()) "Theme: " + ThemeNames[mix.bg]
        else ThemeNames[mix.bg] + " bg · " + ThemeNames[mix.card] + " cards · " +
                ThemeNames[mix.orb] + " circle · " + ThemeNames[mix.acc] + " accent"
        val depthNote = when {
            mix.depth > 0 -> " · +" + (mix.depth / 4) + " cards"
            mix.depth < 0 -> " · " + (mix.depth / 4)
            else -> ""
        }
        Text(name + depthNote, fontSize = 10.sp, color = c.dim, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MiniRow(number: String, text: String) {
    val c = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .background(c.chipBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = c.chipText, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(text, color = c.text, fontSize = 11.sp)
    }
}

@Composable
private fun ThemeTile(index: Int, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalPalette.current
    val t = AllThemes[index]
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        0f to t.bgTop, 0.55f to t.bgTop,
                        0.55f to t.cardBg, 1f to t.cardBg
                    )
                )
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) c.text else c.ring,
                    shape = RoundedCornerShape(12.dp)
                )
                .clickable(onClick = onClick)
        )
        Spacer(Modifier.height(3.dp))
        Text(ThemeNames[index], fontSize = 11.sp, fontWeight = FontWeight.Medium, color = c.text)
    }
}

@Composable
private fun MixSection(label: String, selected: Int, onPick: (Int) -> Unit) {
    val c = LocalPalette.current
    Spacer(Modifier.height(14.dp))
    Text(text = label, fontSize = 10.sp, letterSpacing = 2.sp, color = c.dim)
    Spacer(Modifier.height(6.dp))
    AllThemes.indices.chunked(6).forEach { row ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            row.forEach { i ->
                val t = AllThemes[i]
                val swatch = when (label) {
                    "BACKGROUND" -> t.bgTop
                    "CARDS" -> t.cardBg
                    "BREATHING CIRCLE" -> t.orb
                    else -> t.accent
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(swatch)
                            .border(
                                width = if (selected == i) 3.dp else 1.dp,
                                color = if (selected == i) c.text else c.ring,
                                shape = RoundedCornerShape(9.dp)
                            )
                            .clickable { onPick(i) }
                    )
                    Text(ThemeNames[i], fontSize = 8.sp, color = c.dim)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun DepthChip(mix: Mix, depth: Int, label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalPalette.current
    val bgPrev = AllThemes[mix.bg].bgTop.shiftLightness(minOf(depth, 0).toFloat())
    val cardPrev = AllThemes[mix.card].cardBg.shiftLightness(depth.toFloat())
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(width = 52.dp, height = 30.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(
                    Brush.verticalGradient(
                        0f to bgPrev, 0.5f to bgPrev,
                        0.5f to cardPrev, 1f to cardPrev
                    )
                )
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) c.text else c.ring,
                    shape = RoundedCornerShape(8.dp)
                )
                .clickable(onClick = onClick)
        )
        Text(label, fontSize = 8.sp, color = c.dim)
    }
}

// ---------- Breathing guide (4 in · 4 hold · 6 out) ----------

private enum class BreathPhase(val label: String, val seconds: Int, val targetScale: Float) {
    Inhale("Breathe in", 4, 1f),
    Hold("Hold", 4, 1f),
    Exhale("Breathe out", 6, 0.55f)
}

@Composable
private fun BreathingCircle(
    modifier: Modifier = Modifier,
    circleSize: Dp = 280.dp,
    compact: Boolean = false
) {
    val c = LocalPalette.current
    var phase by remember { mutableStateOf(BreathPhase.Inhale) }
    var count by remember { mutableIntStateOf(BreathPhase.Inhale.seconds) }
    val scale = remember { Animatable(BreathPhase.Exhale.targetScale) }

    LaunchedEffect(Unit) {
        while (isActive) {
            for (p in BreathPhase.entries) {
                phase = p
                count = p.seconds
                coroutineScope {
                    launch {
                        scale.animateTo(
                            targetValue = p.targetScale,
                            animationSpec = tween(
                                durationMillis = p.seconds * 1000,
                                easing = FastOutSlowInEasing
                            )
                        )
                    }
                    launch {
                        repeat(p.seconds) { i ->
                            count = p.seconds - i
                            delay(1000L)
                        }
                    }
                }
            }
        }
    }

    Box(modifier = modifier.size(circleSize), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .matchParentSize()
                .border(1.5.dp, c.ring, CircleShape)
        )
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .background(
                    Brush.radialGradient(
                        listOf(
                            c.orb.copy(alpha = c.orbInnerAlpha),
                            c.orb.copy(alpha = c.orbOuterAlpha)
                        )
                    ),
                    CircleShape
                )
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = phase.label,
                fontSize = if (compact) 12.sp else 22.sp,
                fontWeight = FontWeight.Medium,
                color = c.text
            )
            Spacer(Modifier.height(if (compact) 2.dp else 4.dp))
            Text(
                text = count.toString(),
                fontSize = if (compact) 20.sp else 44.sp,
                fontWeight = FontWeight.Light,
                color = c.text.copy(alpha = 0.9f)
            )
        }
    }
}

// ---------- Small building blocks ----------

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(c.cardBg, RoundedCornerShape(20.dp))
            .border(1.dp, c.cardBorder, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Text(
            text = title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = c.accent
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun GroundingRow(number: String, text: String) {
    val c = LocalPalette.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(c.chipBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = c.chipText,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
        Spacer(Modifier.width(14.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 16.sp,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun ReassuranceLine(text: String) {
    val c = LocalPalette.current
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Text(text = "·", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            color = c.text,
            fontSize = 15.sp,
            lineHeight = 22.sp
        )
    }
}

// ---------- Page 3: Understanding — a little book you swipe through ----------

private data class BookPage(val title: String, val paragraphs: List<String>)

private val BookPages = listOf(
    BookPage(
        "Rolling panic attacks",
        listOf(
            "What you may be feeling is often called a rolling panic attack — multiple attacks stacking over hours, the boundaries blurring so it feels like one relentless wave instead of a single event that ends.",
            "It's a recognized experience, and the reason it keeps returning is mechanical — not a sign that something is medically wrong.",
            "Knowing it has a name, and a cause, is the first step to taking some of its power away."
        )
    ),
    BookPage(
        "The feedback loop",
        listOf(
            "The engine behind it is a feedback loop. An attack floods your body with adrenaline and cortisol. As those drop, symptoms ease briefly — but they leave you in a heightened state of arousal, still primed.",
            "In that primed state, a slightly fast heartbeat, mild dizziness, or shallow breathing gets read by the brain as danger again — and that reading re-fires the whole fight-or-flight response, launching the next wave.",
            "So the very sensations left behind by one wave become the trigger for the next."
        )
    ),
    BookPage(
        "Why watching yourself feeds it",
        listOf(
            "After an attack it's common to start monitoring your own body — watching your breath and heartbeat, braced for the next one.",
            "That hypervigilance is what keeps the nervous system on high alert, which is precisely what feeds the cycle.",
            "It isn't a flaw in you. It's the loop doing what loops do — and it can be interrupted."
        )
    ),
    BookPage(
        "The adrenaline hangover",
        listOf(
            "What you feel after the waves finally stop — the exhaustion, brain fog, aches, being on edge for hours or days — is a separate thing sometimes called an adrenaline hangover.",
            "It's the natural cost of running at full emergency power, repeatedly. It does not mean you're still in danger.",
            "Rest, water, and going easy on yourself are the cure. It passes."
        )
    ),
    BookPage(
        "It isn't your fault",
        listOf(
            "Why some people get rolling waves and others get a single attack isn't fully understood.",
            "It's linked to a more sensitized nervous system, from a mix of genetic, biological, and environmental factors.",
            "None of it comes from anything you did wrong."
        )
    ),
    BookPage(
        "Breaking the loop",
        listOf(
            "The loop can be interrupted, and this app is aimed right at the mechanism.",
            "The breathing lengthens your exhale to pull down the arousal that primes the next wave. For a racing heart, a longer exhale still — around six slow breaths a minute — works best.",
            "The 5-4-3-2-1 forces attention outward, breaking the inward body-scanning that re-triggers you. Mental math helps too: counting backward from 100 by sevens occupies enough of the mind to interrupt the loop. It doesn't matter if you get the numbers right."
        )
    ),
    BookPage(
        "The cold reset",
        listOf(
            "A sharp jolt of cold can break a wave by shocking the system and pulling your attention out of the spiral.",
            "Press an iced bottle to the back of your neck, or to your lower spine — many find that hits harder. Splashing cold water on your face works too.",
            "Keep it moving so it doesn't hurt the skin. Cold is one of the few switches that reaches the nervous system directly."
        )
    ),
    BookPage(
        "When medication shifts",
        listOf(
            "If medication that used to help is starting to slip, that is a signal to see your prescriber — not a failing on your part.",
            "When something long-standing needs more to do the same job, that's exactly the pattern prescribers watch for, and there are usually more options — a different medication, or one that treats the underlying overdrive rather than catching each wave.",
            "Medication catches the wave after it hits. Breathing and cold work on the front end, on the arousal that primes the next one. They aren't competitors — use both."
        )
    ),
    BookPage(
        "You deserve support",
        listOf(
            "Rolling waves are genuinely draining. Knowing they should pass while they keep coming back is its own kind of tired.",
            "If this is happening to you, please treat it as worth a real conversation with a doctor or therapist — not only an app. Rolling panic attacks respond very well to treatment, and a professional can look at your specific pattern in a way an app can't.",
            "If you're ever in an acute crisis, reach out: 988 in the US, or 116 123 across much of the EU. You built the habit of getting through this. You deserve the support too."
        )
    )
)

@Composable
fun BookScreen(onBack: () -> Unit) {
    val c = LocalPalette.current
    var showContents by remember { mutableStateOf(false) }
    val pagerState = rememberPagerState(pageCount = { BookPages.size })
    val rememberScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            val wide = maxWidth > 600.dp
            val colWidth = if (wide) 640.dp else maxWidth
            val hPad = if (wide) 24.dp else 18.dp
            val bodyText = if (wide) 18.sp else 16.sp
            val bodyLine = if (wide) 30.sp else 26.sp

            Column(
                modifier = Modifier
                    .widthIn(max = colWidth)
                    .fillMaxSize()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = hPad, vertical = 14.dp)
            ) {
                // Top bar: back + contents (title lives here, up top by design)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Pill(text = "\u2190 Back to breathing", onClick = onBack)
                    Pill(
                        text = if (showContents) "Close" else "\u2630 Contents",
                        onClick = { showContents = !showContents }
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Understanding the waves",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.text
                )
                Spacer(Modifier.height(12.dp))

                if (showContents) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        BookPages.forEachIndexed { i, p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(c.cardBg)
                                    .border(1.dp, c.cardBorder, RoundedCornerShape(12.dp))
                                    .clickable {
                                        showContents = false
                                        rememberScope.launch { pagerState.animateScrollToPage(i) }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${i + 1}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = c.accent,
                                    modifier = Modifier.width(26.dp)
                                )
                                Text(text = p.title, fontSize = 15.sp, color = c.text)
                            }
                        }
                    }
                } else {
                    // The pages: a real swipeable book. Drag left/right with your finger to flip.
                    Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                        HorizontalPager(
                            state = pagerState,
                            modifier = Modifier.fillMaxSize()
                        ) { pIdx ->
                            val bookPage = BookPages[pIdx]
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(c.cardBg)
                                    .border(1.dp, c.cardBorder, RoundedCornerShape(20.dp))
                                    .padding(horizontal = 24.dp, vertical = 26.dp)
                            ) {
                                Text(
                                    text = "Chapter ${pIdx + 1}",
                                    fontSize = 11.sp,
                                    letterSpacing = 2.sp,
                                    color = c.dim
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = bookPage.title,
                                    fontFamily = FontFamily.Serif,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = c.accent,
                                    lineHeight = 30.sp
                                )
                                Spacer(Modifier.height(18.dp))
                                bookPage.paragraphs.forEach { para ->
                                    Text(
                                        text = para,
                                        fontFamily = FontFamily.Serif,
                                        fontSize = bodyText,
                                        lineHeight = bodyLine,
                                        color = c.text
                                    )
                                    Spacer(Modifier.height(16.dp))
                                }
                            }
                        }

                        // Nav bar CENTERED vertically over the page area (your ask)
                        Row(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            NavArrow(
                                label = "\u2039",
                                enabled = pagerState.currentPage > 0,
                                onClick = { rememberScope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } }
                            )
                            NavArrow(
                                label = "\u203a",
                                enabled = pagerState.currentPage < BookPages.lastIndex,
                                onClick = { rememberScope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } }
                            )
                        }
                    }

                    // Page dots below
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BookPages.indices.forEach { i ->
                                Box(
                                    modifier = Modifier
                                        .size(if (i == pagerState.currentPage) 9.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(if (i == pagerState.currentPage) c.accent else c.dim.copy(alpha = 0.4f))
                                        .clickable { rememberScope.launch { pagerState.animateScrollToPage(i) } }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
private fun NavArrow(label: String, enabled: Boolean, onClick: () -> Unit) {
    val c = LocalPalette.current
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .then(
                if (enabled) Modifier
                    .background(c.cardBg.copy(alpha = 0.92f))
                    .border(1.dp, c.ring, CircleShape)
                else Modifier
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 24.sp,
            fontWeight = FontWeight.Medium,
            color = if (enabled) c.accent else c.dim.copy(alpha = 0.25f)
        )
    }
}
