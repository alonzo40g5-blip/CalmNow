# RULES — Calm Now

## The agreement
This is the owner's project. I build what the owner asks, the way the owner says.
- The owner decides. I do not make design or content choices for him. When something is ambiguous I ask or I show an option first — I do not just pick.
- When the owner says exactly what he wants (a hex, a layout, a behaviour), I do that thing — not my interpretation of it, not a partial version I then call finished.
- I read the request literally. "In the centre" means centre. "Flip like a book" means the page is draggable by finger, not a tapped animation. If I only did half, it is not done.
- I verify before I hand anything over, and I say plainly what still is not done. I never claim something works when I have not confirmed it.
- I own my mistakes without excuses, fix them fully, and don't repeat them.

## Locked facts — do not change without being asked
### The twelve palettes (background · cards · accent)
Days:
- Day 1 Sky — bg E9F2FA · cards E2EDF8 · accent 4E79B0
- Day 3 Warm Cream — bg F7F2E8 · cards F4EEE1 · accent 7C8F6A
- Day 4 Off-White — bg FBFAF7 · cards EFEBDF · accent 7E7A6C
- Day 5 Mist — bg EDF1F4 · cards DBE2E8 · accent 5A7186
- Day 6 Soft Sage — bg EDF2E9 · cards DBE5D2 · accent 6B8261
- Day 7 Blush — bg F6EFEC · cards EAE0DB · accent 9C7C72

Nights (Forest/Plum/Ember are locked at the owner's chosen +2 step):
- Night 1 Deep Navy — bg 0D1726 · cards 182A45 · accent AFC4F5
- Night 2 Slate — bg 26364D · cards 3A4E6E · accent BDD0F7
- Night 3 Evening Sage — bg 3B473E · cards 536354 · accent CFDFC4
- Night 4 Deep Forest — bg 1A4028 · cards 285E3A · accent D6EAC3
- Night 5 Midnight Plum — bg 2D1F4D · cards 443376 · accent D9CAF5
- Night 6 Ember — bg 3E231D · cards 5E3C2C · accent F2BC9C

"Day 2" is retired. Do not bring it back.

### Hard design rules
- Backgrounds NEVER get lighter than their chosen colour. In the tuner, "lighter" moves cards/glow only; the background is clamped. This is welded in and must stay.
- No pure white (#FFFFFF) as a day card colour, ever.
- The contrast guard that keeps any custom mix readable must stay.
- Breathing rhythm is 4 in · 4 hold · 6 out. (A ~6-breaths/min "slow the heart" mode may be added as an option if asked.)

### The app
- Three pages: (1) the breathing/panic screen, (2) "Make it yours" colour studio via the palette button, (3) "Understanding the waves" book via the book button.
- Top-right buttons are 56dp with an 18dp gap (three of them) — big enough to press on a tablet without hitting two at once.
- The book is a real swipeable pager (drag to flip), serif body text, arrows centred over the page, responsive to phone and tablet width.
- Medical content is only positive and points people to real help; crisis numbers 988 (US) and 116 123 (much of EU) stay in.

### Build
- Ships as a zip. GitHub Actions (`.github/workflows/build.yml`) unzips it, compiles with Gradle, and outputs `CalmNow.apk` as an artifact. No Gradle wrapper binary is committed on purpose; the workflow installs its own Gradle.
- Kotlin trap that has bitten before: a public function cannot expose a file-private type (e.g. `Mix`). Any function touching `Mix` must be `private`.

## Current state
Latest build: CalmNow-v13.zip (versionName 2.1). Three pages complete; book is swipe-to-flip with centred arrows.
